import React, { useState, useEffect } from 'react';
import { 
  Flame, 
  Waves, 
  Mountain, 
  CloudRain, 
  Info, 
  ChevronRight, 
  ChevronDown, 
  Sliders, 
  Sparkles, 
  Download, 
  Layers, 
  CheckCircle2,
  FileCode,
  MapPin,
  Building2,
  Hospital,
  Briefcase,
  Compass,
  Search,
  RotateCcw,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';
import { HazardType, FacilityCategory, FacilitySubType, RadarInvestInput, RadarInvestResult } from '../types';
import { HAZARD_LAYERS } from '../data/hazardLayers';

interface LeftSidebarProps {
  selectedHazard: HazardType;
  onSelectHazard: (hazard: HazardType) => void;
  showHazardLayer?: boolean;
  onToggleHazardLayer?: () => void;
  hazardRenderMode?: 'class' | 'index';
  onChangeHazardRenderMode?: (mode: 'class' | 'index') => void;
  opacity: number;
  onChangeOpacity: (val: number) => void;
  showAdminBoundaries: boolean;
  onToggleAdminBoundaries: () => void;
  showPolaRuang: boolean;
  onTogglePolaRuang: () => void;
  showIncidents: boolean;
  onToggleIncidents: () => void;
  selectedIncidentHazards: HazardType[];
  onToggleIncidentHazard: (hazard: HazardType) => void;
  showFacilities: boolean;
  onToggleFacilities: () => void;
  selectedFacilityCategories: FacilityCategory[];
  onToggleFacilityCategory: (category: FacilityCategory) => void;
  selectedFacilitySubTypes: FacilitySubType[];
  onToggleFacilitySubType: (subType: FacilitySubType) => void;
  onRequestAiAnalysis: () => void;
  onExportData: () => void;
  isAiLoading: boolean;
  radarInvestResult?: RadarInvestResult | null;
  onRunRadarInvest?: (input: RadarInvestInput) => void;
  onClearRadarInvest?: () => void;
  isPickingOnMap?: boolean;
  onTogglePickOnMap?: () => void;
  pickedLocation?: { lat: number; lng: number } | null;
}

export const LeftSidebar: React.FC<LeftSidebarProps> = ({
  selectedHazard,
  onSelectHazard,
  showHazardLayer = true,
  onToggleHazardLayer,
  hazardRenderMode = 'class',
  onChangeHazardRenderMode,
  opacity,
  onChangeOpacity,
  showAdminBoundaries,
  onToggleAdminBoundaries,
  showPolaRuang,
  onTogglePolaRuang,
  showIncidents,
  onToggleIncidents,
  selectedIncidentHazards,
  onToggleIncidentHazard,
  showFacilities,
  onToggleFacilities,
  selectedFacilityCategories,
  onToggleFacilityCategory,
  selectedFacilitySubTypes,
  onToggleFacilitySubType,
  onRequestAiAnalysis,
  onExportData,
  isAiLoading,
  radarInvestResult,
  onRunRadarInvest,
  onClearRadarInvest,
  isPickingOnMap = false,
  onTogglePickOnMap,
  pickedLocation,
}) => {
  const [activeTab, setActiveTab] = useState<'tema' | 'ai' | 'invest'>('tema');
  const [expandedSection, setExpandedSection] = useState<'wilayah' | 'polaruang' | 'hazard' | 'incidents' | 'facilities' | null>('polaruang');

  // Form state for Radar Invest
  const [investLat, setInvestLat] = useState<number>(-6.9175);
  const [investLng, setInvestLng] = useState<number>(107.6191);
  const [investPlotHa, setInvestPlotHa] = useState<number>(10);
  const [investSector, setInvestSector] = useState<string>('Manufaktur & Kawasan Industri');
  const [investProjectName, setInvestProjectName] = useState<string>('Rencana Pembangunan Industri');

  // Update form values when user picks a point on map
  useEffect(() => {
    if (pickedLocation) {
      const latFixed = Number(pickedLocation.lat.toFixed(5));
      const lngFixed = Number(pickedLocation.lng.toFixed(5));
      setInvestLat(latFixed);
      setInvestLng(lngFixed);

      if (onRunRadarInvest) {
        onRunRadarInvest({
          lat: latFixed,
          lng: lngFixed,
          plotAreaHa: investPlotHa,
          sector: investSector,
          projectName: investProjectName,
        });
      }
    }
  }, [pickedLocation]);

  const handleApplyPreset = (lat: number, lng: number, ha: number, sec: string, name: string) => {
    setInvestLat(lat);
    setInvestLng(lng);
    setInvestPlotHa(ha);
    setInvestSector(sec);
    setInvestProjectName(name);
    if (onRunRadarInvest) {
      onRunRadarInvest({
        lat,
        lng,
        plotAreaHa: ha,
        sector: sec,
        projectName: name,
      });
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onRunRadarInvest) {
      onRunRadarInvest({
        lat: investLat,
        lng: investLng,
        plotAreaHa: investPlotHa,
        sector: investSector,
        projectName: investProjectName,
      });
    }
  };

  const hazardIcons: Record<HazardType, React.ReactNode> = {
    flood: <Waves className="w-4 h-4 text-blue-400" />,
    landslide: <Mountain className="w-4 h-4 text-amber-400" />,
    wildfire: <Flame className="w-4 h-4 text-orange-400" />,
    coastal: <CloudRain className="w-4 h-4 text-cyan-400" />,
  };


  return (
    <aside className="w-72 bg-slate-950 border-r border-slate-800 text-slate-200 flex flex-col h-[calc(100vh-3.5rem)] shrink-0 z-20 select-none">
      {/* Top Tab Switcher */}
      <div className="flex items-center border-b border-slate-800 p-1.5 bg-slate-900/60 gap-1">
        <button
          onClick={() => setActiveTab('tema')}
          className={`flex-1 py-1.5 px-1.5 rounded-md text-[11px] font-semibold transition-all flex items-center justify-center gap-1 ${
            activeTab === 'tema'
              ? 'bg-slate-800 text-emerald-400 border border-slate-700 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-3 h-3" />
          <span>Tema</span>
        </button>
        <button
          onClick={() => setActiveTab('ai')}
          className={`flex-1 py-1.5 px-1.5 rounded-md text-[11px] font-semibold transition-all flex items-center justify-center gap-1 ${
            activeTab === 'ai'
              ? 'bg-slate-800 text-emerald-400 border border-slate-700 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>Radar</span>
        </button>
        <button
          onClick={() => setActiveTab('invest')}
          className={`flex-1 py-1.5 px-1.5 rounded-md text-[11px] font-semibold transition-all flex items-center justify-center gap-1 relative ${
            activeTab === 'invest'
              ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/80 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Briefcase className="w-3 h-3 text-emerald-400" />
          <span>Invest</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
        </button>
      </div>

      {/* Main Content Scrollable */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {activeTab === 'tema' ? (

          <>
            {/* Accordion 1: WILAYAH (Administrative Layer Toggle) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-lg overflow-hidden">
              <button
                onClick={() => setExpandedSection(expandedSection === 'wilayah' ? null : 'wilayah')}
                className="w-full px-3 py-2.5 flex items-center justify-between text-xs font-bold text-slate-200 hover:bg-slate-800/60 transition-colors"
              >
                <div className="flex items-center gap-2 uppercase tracking-wider text-[11px] text-slate-300">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WILAYAH</span>
                  <Info className="w-3 h-3 text-slate-500" title="Batas Administrasi Kabupaten/Kota Jawa Barat" />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  {expandedSection === 'wilayah' ? (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </button>

              {expandedSection === 'wilayah' && (
                <div className="p-3 border-t border-slate-800 bg-slate-950/60 space-y-2">
                  <label className="flex items-center justify-between p-2 rounded-md bg-slate-900 border border-slate-800/80 cursor-pointer hover:border-slate-700 transition-all">
                    <span className="text-xs text-slate-200 flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={showAdminBoundaries}
                        onChange={onToggleAdminBoundaries}
                        className="rounded bg-slate-800 border-slate-700 text-emerald-500 focus:ring-emerald-500"
                      />
                      <span>Batas Administrasi (Vector)</span>
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-800">
                      8 Kab/Kota
                    </span>
                  </label>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                    Klik pada polygon kabupaten/kota di peta untuk memotong data raster hazard GEE secara spesifik.
                  </p>
                </div>
              )}
            </div>

            {/* Accordion 2: POLA RUANG RTRW (TATA RUANG) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-lg overflow-hidden">
              <button
                onClick={() => setExpandedSection(expandedSection === 'polaruang' ? null : 'polaruang')}
                className="w-full px-3 py-2.5 flex items-center justify-between text-xs font-bold text-slate-200 hover:bg-slate-800/60 transition-colors"
              >
                <div className="flex items-center gap-2 uppercase tracking-wider text-[11px] text-slate-300">
                  <Compass className="w-3.5 h-3.5 text-teal-400" />
                  <span>POLA RUANG (RTRW)</span>
                  <Info className="w-3 h-3 text-slate-500" title="Zonasi Tata Ruang Kawasan Lindung & Kawasan Budi Daya RTRW Dinas PUPR" />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${showPolaRuang ? 'bg-teal-400 animate-pulse' : 'bg-slate-600'}`}></span>
                  {expandedSection === 'polaruang' ? (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </button>

              {expandedSection === 'polaruang' && (
                <div className="p-3 border-t border-slate-800 bg-slate-950/60 space-y-3">
                  {/* Master Toggle */}
                  <label className="flex items-center justify-between p-2 rounded-md bg-slate-900 border border-slate-800 cursor-pointer hover:border-teal-900/50 transition-all">
                    <span className="text-xs text-slate-200 flex items-center gap-2 font-medium">
                      <input
                        type="checkbox"
                        checked={showPolaRuang}
                        onChange={onTogglePolaRuang}
                        className="rounded bg-slate-800 border-slate-700 text-teal-500 focus:ring-teal-500"
                      />
                      <span>Tampilkan Layer Pola Ruang</span>
                    </span>
                    <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                      showPolaRuang 
                        ? 'text-teal-400 bg-teal-950/80 border-teal-800'
                        : 'text-slate-500 bg-slate-900 border-slate-800'
                    }`}>
                      {showPolaRuang ? 'Aktif' : 'Non-Aktif'}
                    </span>
                  </label>

                  {/* Legenda Zonasi RTRW */}
                  <div className="space-y-1.5 pt-1">
                    <div className="text-[10px] text-slate-400 font-mono uppercase tracking-wider flex items-center justify-between">
                      <span>Legenda Pola Ruang RTRW:</span>
                      <span className="text-teal-400 font-semibold">Vector SHP</span>
                    </div>

                    <div className="space-y-1 text-[11px]">
                      <div className="flex items-center justify-between p-1.5 rounded bg-slate-900/90 border border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded bg-emerald-600 border border-emerald-400 shrink-0"></span>
                          <span className="text-slate-200 font-medium">Hutan Lindung (HL)</span>
                        </div>
                        <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950 px-1 py-0.5 rounded border border-emerald-800">Lindung</span>
                      </div>

                      <div className="flex items-center justify-between p-1.5 rounded bg-slate-900/90 border border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded bg-teal-600 border border-teal-400 shrink-0"></span>
                          <span className="text-slate-200 font-medium">Sempadan / KBAU</span>
                        </div>
                        <span className="text-[9px] font-mono text-teal-400 bg-teal-950 px-1 py-0.5 rounded border border-teal-800">Sesar Aktif</span>
                      </div>

                      <div className="flex items-center justify-between p-1.5 rounded bg-slate-900/90 border border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded bg-purple-600 border border-purple-400 shrink-0"></span>
                          <span className="text-slate-200 font-medium">Industri (KPI)</span>
                        </div>
                        <span className="text-[9px] font-mono text-purple-400 bg-purple-950 px-1 py-0.5 rounded border border-purple-800">Budi Daya</span>
                      </div>

                      <div className="flex items-center justify-between p-1.5 rounded bg-slate-900/90 border border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded bg-yellow-500 border border-yellow-300 shrink-0"></span>
                          <span className="text-slate-200 font-medium">Pemukiman (PP-1)</span>
                        </div>
                        <span className="text-[9px] font-mono text-yellow-400 bg-yellow-950 px-1 py-0.5 rounded border border-yellow-800">Budi Daya</span>
                      </div>

                      <div className="flex items-center justify-between p-1.5 rounded bg-slate-900/90 border border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded bg-lime-600 border border-lime-400 shrink-0"></span>
                          <span className="text-slate-200 font-medium">Pertanian (LP2B)</span>
                        </div>
                        <span className="text-[9px] font-mono text-lime-400 bg-lime-950 px-1 py-0.5 rounded border border-lime-800">Budi Daya</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-400 leading-relaxed font-sans border-t border-slate-900 pt-2">
                    Arahkan kursor atau klik pada zonasi Pola Ruang di peta untuk melihat detail batas RTRW, aturan KKPR Dinas PUPR, dan status konservasi.
                  </p>
                </div>
              )}
            </div>

            {/* Accordion 3: LAYER BAHAYA BENCANA (GEE / TIF) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-lg overflow-hidden">
              <div className="w-full px-3 py-2.5 flex items-center justify-between text-xs font-bold text-slate-200 bg-slate-900/90 border-b border-slate-800">
                <button
                  onClick={() => setExpandedSection(expandedSection === 'hazard' ? null : 'hazard')}
                  className="flex items-center gap-2 uppercase tracking-wider text-[11px] text-slate-300 hover:text-slate-100"
                >
                  <Flame className="w-3.5 h-3.5 text-orange-400" />
                  <span>LAYER BAHAYA BENCANA</span>
                  <Info className="w-3 h-3 text-slate-500" title="Dataset Raster .TIF GEE (Opsi Sub-Layer: Kelas Bahaya 1-3 & Indeks Bahaya 0.0-1.0)" />
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onToggleHazardLayer) onToggleHazardLayer();
                    }}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all flex items-center gap-1 ${
                      showHazardLayer
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                    title={showHazardLayer ? 'Sembunyikan Layer Bahaya Bencana di Peta' : 'Tampilkan Layer Bahaya Bencana di Peta'}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${showHazardLayer ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`}></span>
                    <span>{showHazardLayer ? 'Tampil' : 'Sembunyi'}</span>
                  </button>

                  <button
                    onClick={() => setExpandedSection(expandedSection === 'hazard' ? null : 'hazard')}
                    className="p-0.5 hover:bg-slate-800 rounded"
                  >
                    {expandedSection === 'hazard' ? (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    )}
                  </button>
                </div>
              </div>

              {expandedSection === 'hazard' && (
                <div className="p-2.5 bg-slate-950/60 space-y-2.5">
                  {/* Sub-layer Selector Tabs: Kelas Bahaya vs Indeks Bahaya */}
                  <div className="space-y-1">
                    <div className="text-[10px] font-mono uppercase text-slate-400 font-bold flex justify-between">
                      <span>Sub-Layer Tampilan Raster:</span>
                      <span className="text-emerald-400">Format .tif</span>
                    </div>
                    <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800 text-[10px] font-mono font-bold">
                      <button
                        type="button"
                        onClick={() => onChangeHazardRenderMode && onChangeHazardRenderMode('class')}
                        className={`flex-1 py-1.5 px-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 ${
                          hazardRenderMode === 'class'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/80 shadow'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        <span>Kelas Bahaya (1 - 3)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onChangeHazardRenderMode && onChangeHazardRenderMode('index')}
                        className={`flex-1 py-1.5 px-2 rounded-md transition-all text-center flex items-center justify-center gap-1.5 ${
                          hazardRenderMode === 'index'
                            ? 'bg-amber-950 text-amber-300 border border-amber-700/80 shadow'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                        <span>Indeks Bahaya (0.0 - 1.0)</span>
                      </button>
                    </div>
                  </div>

                  {/* List of Hazard Datasets */}
                  <div className="space-y-1.5 pt-1">
                    <div className="text-[10px] font-mono uppercase text-slate-400 font-bold">Pilihan Jenis Ancaman Bencana:</div>
                    {(Object.keys(HAZARD_LAYERS) as HazardType[]).map((key) => {
                      const layer = HAZARD_LAYERS[key];
                      const isSelected = selectedHazard === key;
                      return (
                        <div
                          key={key}
                          onClick={() => onSelectHazard(key)}
                          className={`p-2.5 rounded-lg border cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-slate-800/90 border-emerald-500/80 shadow-md shadow-emerald-950/30'
                              : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/50 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <div className="flex items-center gap-2">
                              {hazardIcons[key]}
                              <span className="text-xs font-semibold text-slate-100">{layer.name}</span>
                            </div>
                            {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                          </div>
                          <p className="text-[10px] text-slate-400 line-clamp-2 leading-normal">
                            {layer.description}
                          </p>
                          <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400 font-mono pt-1.5 border-t border-slate-800/60">
                            <span>Satuan: {layer.unit}</span>
                            <span className="text-emerald-400">
                              {hazardRenderMode === 'class' ? 'Diskrit (1=Low, 2=Med, 3=High)' : 'Kontinu Index (0.0 - 1.0)'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Accordion 3: TITIK KEJADIAN BENCANA (DISASTER INCIDENTS LAYER) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-lg overflow-hidden">
              <button
                onClick={() => setExpandedSection(expandedSection === 'incidents' ? null : 'incidents')}
                className="w-full px-3 py-2.5 flex items-center justify-between text-xs font-bold text-slate-200 hover:bg-slate-800/60 transition-colors"
              >
                <div className="flex items-center gap-2 uppercase tracking-wider text-[11px] text-slate-300">
                  <MapPin className="w-3.5 h-3.5 text-rose-400" />
                  <span>TITIK KEJADIAN BENCANA</span>
                  <Info className="w-3 h-3 text-slate-500" title="Layer Lokasi Kejadian Bencana Lapangan" />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${showIncidents ? 'bg-rose-500 animate-pulse' : 'bg-slate-600'}`}></span>
                  {expandedSection === 'incidents' ? (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </button>

              {expandedSection === 'incidents' && (
                <div className="p-3 border-t border-slate-800 bg-slate-950/60 space-y-3">
                  {/* Master Toggle */}
                  <label className="flex items-center justify-between p-2 rounded-md bg-slate-900 border border-slate-800 cursor-pointer hover:border-rose-900/50 transition-all">
                    <span className="text-xs text-slate-200 flex items-center gap-2 font-medium">
                      <input
                        type="checkbox"
                        checked={showIncidents}
                        onChange={onToggleIncidents}
                        className="rounded bg-slate-800 border-slate-700 text-rose-500 focus:ring-rose-500"
                      />
                      <span>Tampilkan Layer Titik Pin</span>
                    </span>
                    <span className="text-[10px] text-rose-400 font-mono bg-rose-950/80 px-1.5 py-0.5 rounded border border-rose-800">
                      Aktif
                    </span>
                  </label>

                  {/* Filter Custom Jenis Bencana */}
                  <div className="space-y-1.5">
                    <div className="text-[10px] text-slate-400 font-mono uppercase tracking-wider flex items-center justify-between">
                      <span>Filter Jenis Bencana:</span>
                      <span className="text-slate-500">{selectedIncidentHazards.length}/4 Dipilih</span>
                    </div>

                    <div className="grid grid-cols-2 gap-1.5">
                      {([
                        { id: 'flood', label: 'Banjir', color: 'border-blue-500/40 text-blue-400 bg-blue-950/40', icon: '🌊' },
                        { id: 'landslide', label: 'Longsor', color: 'border-amber-500/40 text-amber-400 bg-amber-950/40', icon: '🏔️' },
                        { id: 'wildfire', label: 'Karhutla', color: 'border-orange-500/40 text-orange-400 bg-orange-950/40', icon: '🔥' },
                        { id: 'coastal', label: 'Gelombang', color: 'border-cyan-500/40 text-cyan-400 bg-cyan-950/40', icon: '🌊' },
                      ] as const).map((item) => {
                        const isChecked = selectedIncidentHazards.includes(item.id);
                        return (
                          <button
                            key={item.id}
                            onClick={() => onToggleIncidentHazard(item.id)}
                            className={`p-1.5 rounded-lg border text-left flex items-center gap-1.5 transition-all text-xs font-sans ${
                              isChecked
                                ? `${item.color} font-bold shadow-sm`
                                : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-300'
                            }`}
                          >
                            <span className="text-xs">{item.icon}</span>
                            <span className="text-[11px] truncate">{item.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-400 leading-relaxed font-sans border-t border-slate-900 pt-2">
                    Saat timelapse diputar, tampilan kamera peta akan otomatis bergeser dan fokus pada titik-titik kejadian bencana aktif tahun tersebut.
                  </p>
                </div>
              )}
            </div>

            {/* Accordion 4: LAYER FASILITAS (CRITICAL & PUBLIC FACILITIES) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-lg overflow-hidden">
              <button
                onClick={() => setExpandedSection(expandedSection === 'facilities' ? null : 'facilities')}
                className="w-full px-3 py-2.5 flex items-center justify-between text-xs font-bold text-slate-200 hover:bg-slate-800/60 transition-colors"
              >
                <div className="flex items-center gap-2 uppercase tracking-wider text-[11px] text-slate-300">
                  <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>LAYER FASILITAS</span>
                  <Info className="w-3 h-3 text-slate-500" title="Layer Lokasi Fasilitas Kritis & Fasilitas Umum" />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${showFacilities ? 'bg-emerald-500 animate-pulse' : 'bg-slate-600'}`}></span>
                  {expandedSection === 'facilities' ? (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </button>

              {expandedSection === 'facilities' && (
                <div className="p-3 border-t border-slate-800 bg-slate-950/60 space-y-3">
                  {/* Master Toggle */}
                  <label className="flex items-center justify-between p-2 rounded-md bg-slate-900 border border-slate-800 cursor-pointer hover:border-emerald-900/50 transition-all">
                    <span className="text-xs text-slate-200 flex items-center gap-2 font-medium">
                      <input
                        type="checkbox"
                        checked={showFacilities}
                        onChange={onToggleFacilities}
                        className="rounded bg-slate-800 border-slate-700 text-emerald-500 focus:ring-emerald-500"
                      />
                      <span>Tampilkan Layer Fasilitas</span>
                    </span>
                    <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                      showFacilities 
                        ? 'text-emerald-400 bg-emerald-950/80 border-emerald-800'
                        : 'text-slate-500 bg-slate-900 border-slate-800'
                    }`}>
                      {showFacilities ? 'Aktif' : 'Non-Aktif'}
                    </span>
                  </label>

                  {/* Filter Kategori & Subjenis Fasilitas */}
                  <div className="space-y-3">
                    {/* FASILITAS KRITIS */}
                    <div className="p-2 bg-slate-900/90 rounded-lg border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                        <button
                          onClick={() => onToggleFacilityCategory('kritis')}
                          className="flex items-center gap-1.5 text-xs font-bold text-rose-300 hover:text-rose-200"
                        >
                          <span>🏥 FASILITAS KRITIS</span>
                        </button>
                        <span className="text-[9px] font-mono text-slate-400">
                          {selectedFacilitySubTypes.filter(s => ['Rumah Sakit', 'Posko BPBD', 'Pemadam', 'Polisi'].includes(s)).length}/4 Tampil
                        </span>
                      </div>

                      <div className="space-y-1">
                        {[
                          { id: 'Rumah Sakit' as FacilitySubType, label: 'Rumah Sakit / UGD', icon: '🏥' },
                          { id: 'Posko BPBD' as FacilitySubType, label: 'Posko Utama BPBD', icon: '🛡️' },
                          { id: 'Pemadam' as FacilitySubType, label: 'Pemadam & Rescue', icon: '🚒' },
                          { id: 'Polisi' as FacilitySubType, label: 'Pos Polisi / Keamanan', icon: '🚔' },
                        ].map((sub) => {
                          const isChecked = selectedFacilitySubTypes.includes(sub.id);
                          return (
                            <label
                              key={sub.id}
                              className={`flex items-center justify-between p-1.5 rounded text-[11px] cursor-pointer transition-colors border ${
                                isChecked
                                  ? 'bg-rose-950/30 border-rose-900/50 text-rose-200 font-medium'
                                  : 'bg-slate-950/50 border-slate-900 text-slate-500 hover:text-slate-400'
                              }`}
                            >
                              <span className="flex items-center gap-2">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={() => onToggleFacilitySubType(sub.id)}
                                  className="rounded bg-slate-900 border-slate-700 text-rose-500 focus:ring-rose-500"
                                />
                                <span>{sub.icon}</span>
                                <span>{sub.label}</span>
                              </span>
                              {isChecked && <span className="text-[8px] font-mono text-emerald-400">✓</span>}
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* FASILITAS UMUM */}
                    <div className="p-2 bg-slate-900/90 rounded-lg border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                        <button
                          onClick={() => onToggleFacilityCategory('umum')}
                          className="flex items-center gap-1.5 text-xs font-bold text-blue-300 hover:text-blue-200"
                        >
                          <span>🏫 FASILITAS UMUM</span>
                        </button>
                        <span className="text-[9px] font-mono text-slate-400">
                          {selectedFacilitySubTypes.filter(s => ['Sekolah / Pengungsian', 'Tempat Ibadah', 'Pasar / Logistik', 'Gedung Olahraga'].includes(s)).length}/4 Tampil
                        </span>
                      </div>

                      <div className="space-y-1">
                        {[
                          { id: 'Sekolah / Pengungsian' as FacilitySubType, label: 'Sekolah / Pengungsian', icon: '🏫' },
                          { id: 'Tempat Ibadah' as FacilitySubType, label: 'Tempat Ibadah (Masjid/Gereja)', icon: '🕌' },
                          { id: 'Pasar / Logistik' as FacilitySubType, label: 'Pasar / Logistik Pangan', icon: '📦' },
                          { id: 'Gedung Olahraga' as FacilitySubType, label: 'Gedung Olahraga (GOR)', icon: '🏟️' },
                        ].map((sub) => {
                          const isChecked = selectedFacilitySubTypes.includes(sub.id);
                          return (
                            <label
                              key={sub.id}
                              className={`flex items-center justify-between p-1.5 rounded text-[11px] cursor-pointer transition-colors border ${
                                isChecked
                                  ? 'bg-blue-950/30 border-blue-900/50 text-blue-200 font-medium'
                                  : 'bg-slate-950/50 border-slate-900 text-slate-500 hover:text-slate-400'
                              }`}
                            >
                              <span className="flex items-center gap-2">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={() => onToggleFacilitySubType(sub.id)}
                                  className="rounded bg-slate-900 border-slate-700 text-blue-500 focus:ring-blue-500"
                                />
                                <span>{sub.icon}</span>
                                <span>{sub.label}</span>
                              </span>
                              {isChecked && <span className="text-[8px] font-mono text-emerald-400">✓</span>}
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-400 leading-relaxed font-sans border-t border-slate-900 pt-2">
                    Dua kategori data spasial fasilitas ini membantu pemetaan evakuasi dan kesiapsiagaan tanggap darurat di wilayah terdampak.
                  </p>
                </div>
              )}
            </div>
            <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Transparansi Raster</span>
                </span>
                <span className="font-mono text-emerald-400">{Math.round(opacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={opacity}
                onChange={(e) => onChangeOpacity(parseFloat(e.target.value))}
                className="w-full accent-emerald-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
              />
            </div>

            {/* Active Legend Palette Preview */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3 space-y-2">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                <span>Palet {HAZARD_LAYERS[selectedHazard].name}</span>
                <span className="text-[10px] text-emerald-400 font-mono">
                  {hazardRenderMode === 'class' ? 'Raster Diskrit' : 'Raster Kontinu'}
                </span>
              </div>

              {hazardRenderMode === 'class' ? (
                <div className="grid grid-cols-3 gap-1">
                  <div className="text-center">
                    <div
                      className="h-3 rounded-l"
                      style={{ backgroundColor: HAZARD_LAYERS[selectedHazard].colorPalette.low }}
                    />
                    <span className="text-[9px] text-slate-400 font-mono mt-1 block">1 - Rendah</span>
                  </div>
                  <div className="text-center">
                    <div
                      className="h-3"
                      style={{ backgroundColor: HAZARD_LAYERS[selectedHazard].colorPalette.medium }}
                    />
                    <span className="text-[9px] text-slate-400 font-mono mt-1 block">2 - Sedang</span>
                  </div>
                  <div className="text-center">
                    <div
                      className="h-3 rounded-r"
                      style={{ backgroundColor: HAZARD_LAYERS[selectedHazard].colorPalette.high }}
                    />
                    <span className="text-[9px] text-slate-400 font-mono mt-1 block">3 - Tinggi</span>
                  </div>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="h-3.5 rounded bg-gradient-to-r from-[#10b981] via-[#f59e0b] to-[#f43f5e] border border-slate-700/50 shadow-inner" />
                  <div className="flex justify-between text-[9px] font-mono">
                    <span className="text-emerald-400 font-bold">0.0 (Rendah)</span>
                    <span className="text-amber-400 font-bold">0.5 (Sedang)</span>
                    <span className="text-rose-400 font-bold">1.0 (Tinggi)</span>
                  </div>
                </div>
              )}
            </div>
          </>
        ) : activeTab === 'ai' ? (
          /* MapBiomas AI Tab */
          <div className="space-y-3">
            <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-emerald-900/50 rounded-lg p-3 text-xs space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>RADAR AI Assistant</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Asisten AI cerdas berbasis Gemini 2.5 Flash yang menganalisis statistik kerentanan bencana dari Google Earth Engine secara otomatis.
              </p>
              <button
                onClick={onRequestAiAnalysis}
                disabled={isAiLoading}
                className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-slate-950 font-bold rounded-md transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50"
              >
                {isAiLoading ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span>
                    <span>Menganalisis GEE...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Jalankan Analisis Risiko AI</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          /* RADAR INVEST TAB (DUNIA USAHA) */
          <div className="space-y-3 text-xs">
            <div className="bg-gradient-to-b from-emerald-950/40 via-slate-900 to-slate-950 border border-emerald-800/60 rounded-xl p-3 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-bold text-emerald-300 text-xs">
                  <Briefcase className="w-4 h-4 text-emerald-400" />
                  <span>RADAR INVEST (DUNIA USAHA)</span>
                </div>
                <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800">
                  KKPR & Spatial
                </span>
              </div>
              <p className="text-[11px] text-slate-300 leading-snug">
                Sistem analitik kelayakan tapak pembangunan. Masukkan titik koordinat (X, Y) untuk evaluasi status Kawasan Lindung, Risiko Bencana, dan Statistik Luas (Ha).
              </p>
            </div>

            {/* Input Form Koordinat Manual */}
            <form onSubmit={handleFormSubmit} className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 space-y-2.5">
              <div className="text-[11px] font-bold text-slate-200 flex items-center justify-between">
                <span>INPUT KOORDINAT TAPAK</span>
                <Compass className="w-3.5 h-3.5 text-emerald-400" />
              </div>

              {/* Button: Pilih Berdasarkan Peta */}
              <button
                type="button"
                onClick={onTogglePickOnMap}
                className={`w-full py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 border shadow-sm ${
                  isPickingOnMap
                    ? 'bg-amber-950 text-amber-300 border-amber-600 animate-pulse'
                    : 'bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border-emerald-700/80 hover:border-emerald-500'
                }`}
              >
                <MapPin className={`w-4 h-4 ${isPickingOnMap ? 'text-amber-400 animate-bounce' : 'text-emerald-400'}`} />
                <span>{isPickingOnMap ? 'Klik Lokasi di Peta... (Batal)' : 'Pilih Berdasarkan Peta'}</span>
              </button>

              <div>
                <label className="block text-[10px] text-slate-400 font-mono mb-1">Nama Proyek / Kegiatan Usaha</label>
                <input
                  type="text"
                  value={investProjectName}
                  onChange={(e) => setInvestProjectName(e.target.value)}
                  placeholder="misal: Kawasan Industri Cikarang"
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">Latitude Y (Lintang)</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={investLat}
                    onChange={(e) => setInvestLat(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">Longitude X (Bujur)</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={investLng}
                    onChange={(e) => setInvestLng(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">Rencana Luas Plot (Ha)</label>
                  <input
                    type="number"
                    min="0.5"
                    step="0.5"
                    value={investPlotHa}
                    onChange={(e) => setInvestPlotHa(parseFloat(e.target.value) || 1)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 font-mono mb-1">Sektor Usaha</label>
                  <select
                    value={investSector}
                    onChange={(e) => setInvestSector(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded px-1.5 py-1.5 text-[11px] text-slate-200 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Manufaktur & Kawasan Industri">Industri & Pabrik</option>
                    <option value="Perumahan & Real Estate">Perumahan & Properti</option>
                    <option value="Pariwisata & Resort / Hotel">Pariwisata & Hotel</option>
                    <option value="Energi, Pertambangan & Infrastruktur">Infrastruktur & Energi</option>
                    <option value="Pertanian, Agribisnis & Peternakan">Agribisnis & Pertanian</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Analisis Kelayakan Tapak</span>
              </button>
            </form>

            {/* Quick Presets Sample Locations in Jabar */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 space-y-2">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                LOKASI CONOH PRESET (SIMULASI JABAR)
              </div>
              <div className="space-y-1.5">
                {[
                  {
                    name: '🏬 Kawasan Industri Cikarang (Budi Daya)',
                    lat: -6.3150,
                    lng: 107.1520,
                    ha: 25,
                    sec: 'Manufaktur & Kawasan Industri',
                    proj: 'Pembangunan Pabrik & Gudang Cikarang'
                  },
                  {
                    name: '🌲 Ciwidey Patuha (Kawasan Lindung)',
                    lat: -7.1650,
                    lng: 107.4120,
                    ha: 15,
                    sec: 'Pariwisata & Resort / Hotel',
                    proj: 'Pengembangan Resort Ciwidey'
                  },
                  {
                    name: '🏙️ Lembang (Resapan Air & Sesar)',
                    lat: -6.8120,
                    lng: 107.6210,
                    ha: 8,
                    sec: 'Perumahan & Real Estate',
                    proj: 'Kawasan Komersial Lembang'
                  },
                  {
                    name: '🌊 Pesisir Cirebon (Rob Pesisir)',
                    lat: -6.7410,
                    lng: 108.5420,
                    ha: 20,
                    sec: 'Manufaktur & Kawasan Industri',
                    proj: 'Pusat Logistik Pesisir Cirebon'
                  },
                  {
                    name: '🗻 Cugenang Cianjur (Zona Sesar)',
                    lat: -6.8020,
                    lng: 107.1120,
                    ha: 12,
                    sec: 'Energi, Pertambangan & Infrastruktur',
                    proj: 'Depot Sub-Stasiun Cugenang'
                  },
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleApplyPreset(preset.lat, preset.lng, preset.ha, preset.sec, preset.proj)}
                    className="w-full p-2 bg-slate-950/80 hover:bg-slate-800 border border-slate-800/80 rounded-lg text-left text-[11px] transition-all flex items-center justify-between group"
                  >
                    <div>
                      <div className="font-semibold text-slate-200 group-hover:text-emerald-300">{preset.name}</div>
                      <div className="text-[9px] text-slate-500 font-mono">
                        X: {preset.lng}, Y: {preset.lat} • {preset.ha} Ha
                      </div>
                    </div>
                    <span className="text-[10px] text-emerald-400 font-mono font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                      Pilih →
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* If Result Active */}
            {radarInvestResult && (
              <div className="bg-emerald-950/40 border border-emerald-700/80 rounded-xl p-3 space-y-2.5">
                <div className="flex items-center justify-between pb-1 border-b border-emerald-900/60">
                  <span className="text-[10px] font-bold text-emerald-300 font-mono flex items-center gap-1">
                    <CheckCircle className="w-3 h-3 text-emerald-400" />
                    ANALISIS AKTIF
                  </span>
                  <button
                    onClick={onClearRadarInvest}
                    className="text-[10px] text-slate-400 hover:text-rose-400 flex items-center gap-1 font-mono transition-colors"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                </div>
                <div className="text-xs font-bold text-slate-100">{radarInvestResult.projectName}</div>
                <div className="text-[10px] text-slate-300 font-mono">
                  📍 {radarInvestResult.districtName} ({radarInvestResult.villageName})
                </div>
                
                <div className={`p-2 rounded-lg text-[10px] font-bold text-center font-mono border ${
                  radarInvestResult.feasibilityStatus.includes('ZONA MERAH')
                    ? 'bg-rose-950/90 text-rose-300 border-rose-700'
                    : radarInvestResult.feasibilityStatus.includes('ZONA KUNING')
                    ? 'bg-amber-950/90 text-amber-300 border-amber-700'
                    : 'bg-emerald-950/90 text-emerald-300 border-emerald-700'
                }`}>
                  {radarInvestResult.feasibilityStatus}
                </div>

                {/* Deskripsi & Alasan Status */}
                {radarInvestResult.feasibilityReasons && radarInvestResult.feasibilityReasons.length > 0 && (
                  <div className="space-y-1.5 pt-1 border-t border-slate-800/80">
                    <div className="text-[10px] font-bold text-slate-300 font-mono uppercase tracking-wider flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 text-amber-400" />
                      <span>Alasan Status Zona:</span>
                    </div>
                    {radarInvestResult.feasibilitySummary && (
                      <p className="text-[10px] text-slate-300 leading-snug bg-slate-950/70 p-2 rounded border border-slate-800">
                        {radarInvestResult.feasibilitySummary}
                      </p>
                    )}
                    <ul className="space-y-1 max-h-48 overflow-y-auto pr-1">
                      {radarInvestResult.feasibilityReasons.map((reason, idx) => (
                        <li
                          key={idx}
                          className={`text-[10px] p-1.5 rounded border leading-relaxed ${
                            radarInvestResult.feasibilityStatus.includes('ZONA MERAH')
                              ? 'bg-rose-950/40 border-rose-900/50 text-rose-200'
                              : radarInvestResult.feasibilityStatus.includes('ZONA KUNING')
                              ? 'bg-amber-950/40 border-amber-900/50 text-amber-200'
                              : 'bg-emerald-950/40 border-emerald-900/50 text-emerald-200'
                          }`}
                        >
                          {reason}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>


      {/* Bottom Sticky Action Buttons */}
      <div className="p-3 border-t border-slate-800 bg-slate-950 grid grid-cols-2 gap-2 shrink-0">
        <button
          onClick={onRequestAiAnalysis}
          className="py-2 px-2.5 bg-slate-900 hover:bg-slate-800 text-slate-100 font-semibold text-xs border border-slate-700/80 rounded-lg transition-all flex items-center justify-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Buat analisis</span>
          <span className="text-[9px] text-amber-400 font-mono">beta</span>
        </button>

        <button
          onClick={onExportData}
          className="py-2 px-2.5 bg-slate-900 hover:bg-slate-800 text-slate-100 font-semibold text-xs border border-slate-700/80 rounded-lg transition-all flex items-center justify-center gap-1.5"
        >
          <Download className="w-3.5 h-3.5 text-emerald-400" />
          <span>Downloads</span>
        </button>
      </div>
    </aside>
  );
};
