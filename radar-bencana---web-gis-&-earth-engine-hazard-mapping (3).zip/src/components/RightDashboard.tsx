import React, { useState, useEffect } from 'react';
import { 
  PieChart as PieIcon, 
  Share2, 
  Download, 
  Maximize2, 
  Eye, 
  Sparkles, 
  ShieldAlert, 
  Building2, 
  GraduationCap, 
  Anchor, 
  Users, 
  MapPin, 
  ChevronRight,
  TrendingUp,
  FileText,
  AlertTriangle,
  Info,
  Briefcase,
  CheckCircle,
  XCircle,
  AlertCircle,
  Compass,
  Check
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { AdminFeature, ZonalStatistics, AIRiskAssessment, HazardType, FacilitySubType, RadarInvestResult } from '../types';
import { HAZARD_LAYERS } from '../data/hazardLayers';
import { MOCK_FACILITIES } from '../data/mockFacilities';

interface RightDashboardProps {
  selectedDistrict: AdminFeature | null;
  selectedHazard: HazardType;
  stats: ZonalStatistics | null;
  aiAssessment: AIRiskAssessment | null;
  isAiLoading: boolean;
  onRequestAiAnalysis: () => void;
  onExportData: () => void;
  radarInvestResult?: RadarInvestResult | null;
}

export const RightDashboard: React.FC<RightDashboardProps> = ({
  selectedDistrict,
  selectedHazard,
  stats,
  aiAssessment,
  isAiLoading,
  onRequestAiAnalysis,
  onExportData,
  radarInvestResult,
}) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'invest' | 'ai'>('stats');

  // Auto switch tab when a district is selected or investment analysis computed
  useEffect(() => {
    if (selectedDistrict) {
      setActiveTab('stats');
    }
  }, [selectedDistrict]);

  useEffect(() => {
    if (radarInvestResult) {
      setActiveTab('invest');
    }
  }, [radarInvestResult]);


  const hazardConfig = HAZARD_LAYERS[selectedHazard];

  // Filter facilities clipped by selected district
  const districtFacilities = MOCK_FACILITIES.filter((fac) => {
    if (!selectedDistrict) return true; // All facilities if no district selected
    const selectedName = selectedDistrict.properties.name.toLowerCase().replace(/^(kabupaten|kota)\s+/, '');
    const facName = fac.districtName.toLowerCase().replace(/^(kabupaten|kota)\s+/, '');
    return facName.includes(selectedName) || selectedName.includes(facName);
  });

  const kritisFacilities = districtFacilities.filter((f) => f.category === 'kritis');
  const umumFacilities = districtFacilities.filter((f) => f.category === 'umum');

  const countBySubType = (subType: FacilitySubType) => 
    districtFacilities.filter((f) => f.subType === subType).length;

  // Prepare chart data matching MapBiomas Sunburst/Donut style (3 hazard classes)
  const chartData = stats
    ? [
        {
          name: 'Tinggi (High Risk - Class 3)',
          value: stats.highRiskHa,
          pct: stats.highRiskPct,
          color: hazardConfig.colorPalette.high,
        },
        {
          name: 'Sedang (Moderate - Class 2)',
          value: stats.mediumRiskHa,
          pct: stats.mediumRiskPct,
          color: hazardConfig.colorPalette.medium,
        },
        {
          name: 'Rendah (Low Hazard - Class 1)',
          value: stats.lowRiskHa,
          pct: stats.lowRiskPct,
          color: hazardConfig.colorPalette.low,
        },
      ]
    : [];

  const districtName = selectedDistrict
    ? selectedDistrict.properties.name
    : 'Jawa Barat (Full Region)';
  const totalArea = stats ? stats.totalAreaHa.toLocaleString() : '12,980,500';

  return (
    <aside className="w-80 lg:w-96 bg-slate-950 border-l border-slate-800 text-slate-200 flex flex-col h-[calc(100vh-3.5rem)] shrink-0 z-20 select-none">
      {/* Top Header Title Panel (Matching Screenshot) */}
      <div className="p-4 border-b border-slate-800 bg-slate-900/60">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono font-semibold">
            <MapPin className="w-3.5 h-3.5" />
            <span>{selectedDistrict ? selectedDistrict.properties.type : 'Provinsi'}</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={onExportData}
              className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
              title="Download Data Report"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => {
                navigator.clipboard.writeText(window.location.href);
                alert('Link dashboard disalin!');
              }}
              className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
              title="Bagikan Tampilan"
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <h2 className="text-xl font-extrabold text-slate-100 tracking-tight">{districtName}</h2>
        <p className="text-[11px] text-slate-400 font-mono mt-0.5">
          Wilayah • Hazard berdasarkan kelas • 2024
        </p>

        {/* Action Badge Button */}
        <div className="mt-3 flex items-center justify-between">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-800/80 border border-slate-700/80 rounded-full text-xs font-semibold text-emerald-400">
            <Eye className="w-3.5 h-3.5" />
            <span>Divisualisasikan pada peta</span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono">GEE reduceRegion</span>
        </div>
      </div>

      {/* Tab Selector */}
      <div className="flex items-center border-b border-slate-800 bg-slate-900/40 p-1 gap-1">
        <button
          onClick={() => setActiveTab('stats')}
          className={`flex-1 py-1.5 text-[11px] font-semibold rounded-md transition-all flex items-center justify-center gap-1 ${
            activeTab === 'stats'
              ? 'bg-slate-800 text-slate-100 shadow-sm border border-slate-700'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <PieIcon className="w-3.5 h-3.5 text-emerald-400" />
          <span>Statistik Luas (ha)</span>
        </button>
        <button
          onClick={() => setActiveTab('invest')}
          className={`flex-1 py-1.5 text-[11px] font-semibold rounded-md transition-all flex items-center justify-center gap-1 relative ${
            activeTab === 'invest'
              ? 'bg-emerald-950 text-emerald-300 shadow-sm border border-emerald-700/80 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Briefcase className="w-3.5 h-3.5 text-emerald-400" />
          <span>Analitik Radar Invest</span>
          {radarInvestResult && (
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('ai')}
          className={`flex-1 py-1.5 text-[11px] font-semibold rounded-md transition-all flex items-center justify-center gap-1 ${
            activeTab === 'ai'
              ? 'bg-slate-800 text-slate-100 shadow-sm border border-slate-700'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Laporan AI BPBD</span>
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {activeTab === 'stats' ? (

          <>
            {/* Donut / Sunburst Chart Section */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl">
              <div className="text-xs font-bold text-slate-300 mb-2 flex items-center justify-between">
                <span>DISTRIBUSI HAZARD (HA)</span>
                <span className="text-[10px] font-mono text-emerald-400">Total: {totalArea} ha</span>
              </div>

              {/* Recharts Multi-ring Donut */}
              <div className="h-52 w-full relative my-2">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} stroke="#0f172a" strokeWidth={2} />
                      ))}
                    </Pie>
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-slate-900 border border-slate-700 p-2 rounded shadow-2xl text-xs font-mono">
                              <div className="font-bold text-slate-100">{data.name}</div>
                              <div className="text-emerald-400">{data.value.toLocaleString()} ha ({data.pct}%)</div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>

                {/* Donut Hole Center Text */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-[10px] text-slate-400 font-mono uppercase">Status Risk</span>
                  <span className={`text-sm font-extrabold font-mono ${
                    stats?.riskCategory === 'Critical' ? 'text-rose-500' : 'text-amber-400'
                  }`}>
                    {stats?.riskCategory || 'High'}
                  </span>
                </div>
              </div>

              {/* Detailed Legend List */}
              <div className="space-y-2 mt-4 pt-3 border-t border-slate-800/80">
                {chartData.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }}></span>
                      <span className="text-slate-300 text-[11px] truncate max-w-[170px]">{item.name}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-slate-100">{item.value.toLocaleString()} ha</span>
                      <span className="text-slate-400 text-[10px] ml-1">({item.pct}%)</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Rincian Fasilitas Terdampak / Terpotong (Clipped) */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div>
                  <div className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <Building2 className="w-4 h-4 text-emerald-400" />
                    <span>FASILITAS & INFRASTRUKTUR</span>
                  </div>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                    {selectedDistrict ? `Kliping Wilayah: ${districtName}` : 'Seluruh Jawa Barat'}
                  </p>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-950/80 border border-emerald-800 text-emerald-300">
                  {districtFacilities.length} Unit Total
                </span>
              </div>

              {/* Grid Fasilitas Kritis */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-rose-300 font-mono flex items-center justify-between">
                  <span>🏥 FASILITAS KRITIS ({kritisFacilities.length})</span>
                  <span className="text-[9px] text-slate-400">Tanggap Darurat</span>
                </div>
                <div className="grid grid-cols-2 gap-1.5 text-xs font-mono">
                  <div className="bg-slate-950/90 border border-rose-900/40 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-[10px] text-slate-300 flex items-center gap-1">
                      <span>🏥</span>
                      <span className="truncate">Rumah Sakit</span>
                    </span>
                    <span className="font-bold text-rose-400 text-xs ml-1">{countBySubType('Rumah Sakit')}</span>
                  </div>
                  <div className="bg-slate-950/90 border border-rose-900/40 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-[10px] text-slate-300 flex items-center gap-1">
                      <span>🛡️</span>
                      <span className="truncate">Pos BPBD</span>
                    </span>
                    <span className="font-bold text-rose-400 text-xs ml-1">{countBySubType('Posko BPBD')}</span>
                  </div>
                  <div className="bg-slate-950/90 border border-rose-900/40 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-[10px] text-slate-300 flex items-center gap-1">
                      <span>🚒</span>
                      <span className="truncate">Pemadam</span>
                    </span>
                    <span className="font-bold text-rose-400 text-xs ml-1">{countBySubType('Pemadam')}</span>
                  </div>
                  <div className="bg-slate-950/90 border border-rose-900/40 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-[10px] text-slate-300 flex items-center gap-1">
                      <span>🚔</span>
                      <span className="truncate">Polisi</span>
                    </span>
                    <span className="font-bold text-rose-400 text-xs ml-1">{countBySubType('Polisi')}</span>
                  </div>
                </div>
              </div>

              {/* Grid Fasilitas Umum */}
              <div className="space-y-1.5 pt-1">
                <div className="text-[11px] font-bold text-blue-300 font-mono flex items-center justify-between">
                  <span>🏫 FASILITAS UMUM ({umumFacilities.length})</span>
                  <span className="text-[9px] text-slate-400">Pengungsian & Logistik</span>
                </div>
                <div className="grid grid-cols-2 gap-1.5 text-xs font-mono">
                  <div className="bg-slate-950/90 border border-blue-900/40 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-[10px] text-slate-300 flex items-center gap-1">
                      <span>🏫</span>
                      <span className="truncate">Sekolah/Evak</span>
                    </span>
                    <span className="font-bold text-blue-400 text-xs ml-1">{countBySubType('Sekolah / Pengungsian')}</span>
                  </div>
                  <div className="bg-slate-950/90 border border-blue-900/40 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-[10px] text-slate-300 flex items-center gap-1">
                      <span>🕌</span>
                      <span className="truncate">Tempat Ibadah</span>
                    </span>
                    <span className="font-bold text-blue-400 text-xs ml-1">{countBySubType('Tempat Ibadah')}</span>
                  </div>
                  <div className="bg-slate-950/90 border border-blue-900/40 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-[10px] text-slate-300 flex items-center gap-1">
                      <span>📦</span>
                      <span className="truncate">Pasar/Logistik</span>
                    </span>
                    <span className="font-bold text-blue-400 text-xs ml-1">{countBySubType('Pasar / Logistik')}</span>
                  </div>
                  <div className="bg-slate-950/90 border border-blue-900/40 p-2 rounded-lg flex items-center justify-between">
                    <span className="text-[10px] text-slate-300 flex items-center gap-1">
                      <span>🏟️</span>
                      <span className="truncate">GOR</span>
                    </span>
                    <span className="font-bold text-blue-400 text-xs ml-1">{countBySubType('Gedung Olahraga')}</span>
                  </div>
                </div>
              </div>

              {/* Daftar Fasilitas Terpotong di Wilayah Ini */}
              <div className="space-y-1.5 pt-2 border-t border-slate-800">
                <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex justify-between items-center">
                  <span>Daftar Unit Fasilitas ({districtFacilities.length}):</span>
                  {selectedDistrict && <span className="text-emerald-400 font-bold">✓ Terclip</span>}
                </div>
                <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                  {districtFacilities.length > 0 ? (
                    districtFacilities.map((fac) => (
                      <div
                        key={fac.id}
                        className="p-2 bg-slate-950/90 rounded-lg border border-slate-800 text-[11px] space-y-1 hover:border-slate-700 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-1">
                          <span className="font-bold text-slate-200 leading-tight">
                            {fac.category === 'kritis' ? '🏥' : '🏫'} {fac.name}
                          </span>
                          <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded border shrink-0 ${
                            fac.category === 'kritis' 
                              ? 'bg-rose-950/80 border-rose-800 text-rose-300' 
                              : 'bg-blue-950/80 border-blue-800 text-blue-300'
                          }`}>
                            {fac.subType}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 leading-snug">{fac.address}</p>
                        <div className="flex items-center justify-between text-[9px] font-mono text-slate-400 border-t border-slate-900 pt-1">
                          <span>{fac.districtName}</span>
                          <span className="text-emerald-400 font-semibold">{fac.status}</span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-3 text-center text-[10px] text-slate-500 font-mono bg-slate-950 rounded-lg border border-slate-900">
                      Tidak ada titik fasilitas tercatat di wilayah ini.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        ) : activeTab === 'invest' ? (
          /* RADAR INVEST ANALYTICS VIEW */
          <div className="space-y-4">
            {radarInvestResult ? (
              <div className="space-y-3">
                {/* Investment Header Banner */}
                <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 border border-emerald-800/80 rounded-2xl p-4 space-y-2 shadow-xl">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                      <Briefcase className="w-4 h-4 text-emerald-400" />
                      <span>ANALITIK RADAR INVEST</span>
                    </div>
                    <span className="text-[9px] bg-emerald-950 text-emerald-300 border border-emerald-700/80 px-2 py-0.5 rounded font-mono font-bold">
                      Dunia Usaha & KKPR
                    </span>
                  </div>

                  <h3 className="text-base font-extrabold text-slate-100">{radarInvestResult.projectName}</h3>

                  <div className="grid grid-cols-2 gap-2 pt-1 text-[11px] font-mono text-slate-300">
                    <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                      <span className="text-[9px] text-slate-500 block">KOORDINAT TAPAK (X, Y)</span>
                      <span className="text-emerald-400 font-bold">Y: {radarInvestResult.lat}, X: {radarInvestResult.lng}</span>
                    </div>
                    <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                      <span className="text-[9px] text-slate-500 block">SEKTOR USANAA</span>
                      <span className="text-slate-200 font-semibold truncate block">{radarInvestResult.sector}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-mono pt-1">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{radarInvestResult.villageName}, {radarInvestResult.subdistrictName}, {radarInvestResult.districtName}</span>
                  </div>
                </div>

                {/* Status Feasibility & KKPR */}
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <div className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                    <span>KESESUAIAN TATA RUANG (KKPR)</span>
                    <ShieldAlert className="w-4 h-4 text-emerald-400" />
                  </div>

                  <div className={`p-3 rounded-xl border flex items-center gap-3 ${
                    radarInvestResult.feasibilityStatus.includes('ZONA MERAH')
                      ? 'bg-rose-950/60 border-rose-800/80 text-rose-200'
                      : radarInvestResult.feasibilityStatus.includes('ZONA KUNING')
                      ? 'bg-amber-950/60 border-amber-800/80 text-amber-200'
                      : 'bg-emerald-950/60 border-emerald-800/80 text-emerald-200'
                  }`}>
                    {radarInvestResult.feasibilityStatus.includes('ZONA MERAH') ? (
                      <XCircle className="w-7 h-7 text-rose-400 shrink-0" />
                    ) : radarInvestResult.feasibilityStatus.includes('ZONA KUNING') ? (
                      <AlertCircle className="w-7 h-7 text-amber-400 shrink-0" />
                    ) : (
                      <CheckCircle className="w-7 h-7 text-emerald-400 shrink-0" />
                    )}
                    <div>
                      <div className="text-xs font-extrabold">{radarInvestResult.feasibilityStatus}</div>
                      <div className="text-[10px] opacity-90 mt-0.5 leading-snug">{radarInvestResult.kkprStatus}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-mono">STATUS KAWASAN LINDUNG</span>
                      <span className={`font-bold ${radarInvestResult.isProtectedZone ? 'text-rose-400' : 'text-emerald-400'}`}>
                        {radarInvestResult.isProtectedZone ? '🔴 Kawasan Lindung' : '🟢 Kawasan Budi Daya'}
                      </span>
                    </div>
                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-mono">KATEGORI ZONA</span>
                      <span className="font-bold text-slate-200">{radarInvestResult.zoneCategory}</span>
                    </div>
                  </div>

                  {/* ALASAN DEKSRIPSI STATUS ZONA */}
                  {radarInvestResult.feasibilityReasons && radarInvestResult.feasibilityReasons.length > 0 && (
                    <div className="pt-2 border-t border-slate-800 space-y-2">
                      <div className="text-[11px] font-extrabold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                        <span>ALASAN STATUS ZONA & ANALISIS PENYEBAB</span>
                      </div>

                      {radarInvestResult.feasibilitySummary && (
                        <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                          {radarInvestResult.feasibilitySummary}
                        </p>
                      )}

                      <div className="space-y-1.5">
                        {radarInvestResult.feasibilityReasons.map((reason, idx) => (
                          <div
                            key={idx}
                            className={`p-2.5 rounded-lg border text-xs font-medium leading-relaxed flex items-start gap-2 ${
                              radarInvestResult.feasibilityStatus.includes('ZONA MERAH')
                                ? 'bg-rose-950/40 border-rose-900/60 text-rose-200'
                                : radarInvestResult.feasibilityStatus.includes('ZONA KUNING')
                                ? 'bg-amber-950/40 border-amber-900/60 text-amber-200'
                                : 'bg-emerald-950/40 border-emerald-900/60 text-emerald-200'
                            }`}
                          >
                            <span className="shrink-0 mt-0.5">
                              {radarInvestResult.feasibilityStatus.includes('ZONA MERAH') ? '🚫' : radarInvestResult.feasibilityStatus.includes('ZONA KUNING') ? '⚠️' : '✅'}
                            </span>
                            <span>{reason}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* STATISTIK LUAS (HA) - USER REQUESTED TITLE */}
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                    <h4 className="text-xs font-extrabold text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                      <span>STATISTIK LUAS (HA)</span>
                    </h4>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold">
                      Plot Total: {radarInvestResult.plotAreaHa} Ha
                    </span>
                  </div>

                  {/* Visual Bar Breakdown */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[10px] font-mono text-slate-400">
                      <span>Rincian Komposisi Lahan</span>
                      <span>100%</span>
                    </div>
                    <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden flex border border-slate-800">
                      <div
                        style={{ width: `${(radarInvestResult.areaBreakdown.buildableAreaHa / radarInvestResult.plotAreaHa) * 100}%` }}
                        className="bg-emerald-500 h-full"
                        title="Dapat Dibangun"
                      />
                      <div
                        style={{ width: `${(radarInvestResult.areaBreakdown.protectedAreaHa / radarInvestResult.plotAreaHa) * 100}%` }}
                        className="bg-rose-500 h-full"
                        title="Zona Lindung/Resapan"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                    <div className="bg-slate-950 p-2.5 rounded-xl border border-emerald-900/40 space-y-1">
                      <span className="text-slate-400 text-[10px] block">Dapat Dibangun (Budi Daya)</span>
                      <span className="text-sm font-bold text-emerald-400">{radarInvestResult.areaBreakdown.buildableAreaHa} Ha</span>
                      <span className="text-[9px] text-slate-500 block">
                        ({Math.round((radarInvestResult.areaBreakdown.buildableAreaHa / radarInvestResult.plotAreaHa) * 100)}% dari plot)
                      </span>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-xl border border-rose-900/40 space-y-1">
                      <span className="text-slate-400 text-[10px] block">Zona Lindung / Buffer</span>
                      <span className="text-sm font-bold text-rose-400">{radarInvestResult.areaBreakdown.protectedAreaHa} Ha</span>
                      <span className="text-[9px] text-slate-500 block">
                        ({Math.round((radarInvestResult.areaBreakdown.protectedAreaHa / radarInvestResult.plotAreaHa) * 100)}% dari plot)
                      </span>
                    </div>
                  </div>

                  {/* Risk Level Distribution Breakdown */}
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
                    <span className="text-[10px] text-slate-400 font-mono font-bold block uppercase">
                      Distribusi Tingkat Kerentanan Bencana (Ha)
                    </span>
                    <div className="grid grid-cols-3 gap-1.5 text-center text-[10px] font-mono">
                      <div className="bg-rose-950/40 border border-rose-900/50 p-1.5 rounded">
                        <span className="text-rose-400 block font-bold">{radarInvestResult.areaBreakdown.highRiskAreaHa} Ha</span>
                        <span className="text-slate-400 text-[9px]">Tinggi</span>
                      </div>
                      <div className="bg-amber-950/40 border border-amber-900/50 p-1.5 rounded">
                        <span className="text-amber-400 block font-bold">{radarInvestResult.areaBreakdown.mediumRiskAreaHa} Ha</span>
                        <span className="text-slate-400 text-[9px]">Sedang</span>
                      </div>
                      <div className="bg-emerald-950/40 border border-emerald-900/50 p-1.5 rounded">
                        <span className="text-emerald-400 block font-bold">{radarInvestResult.areaBreakdown.lowRiskAreaHa} Ha</span>
                        <span className="text-slate-400 text-[9px]">Rendah</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Potensi Bencana pada Titik Tapak */}
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>STATUS POTENSI BENCANA LOKASI</span>
                  </h4>

                  <div className="space-y-2 text-xs">
                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-[11px] font-bold text-slate-200">
                        <span>🏔️ Tanah Longsor & Gerakan Tanah</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-amber-950 text-amber-300 border border-amber-800">
                          {radarInvestResult.disasterPotentials?.landslide || radarInvestResult.hazardPotentials?.find(h => h.hazard.includes('Longsor'))?.risk || 'Rendah'}
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-[11px] font-bold text-slate-200">
                        <span>🌊 Banjir & Genangan Air</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-blue-950 text-blue-300 border border-blue-800">
                          {radarInvestResult.disasterPotentials?.flood || radarInvestResult.hazardPotentials?.find(h => h.hazard.includes('Banjir'))?.risk || 'Rendah'}
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-[11px] font-bold text-slate-200">
                        <span>⚡ Sesar Aktif / Gempa Tektonik</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-purple-950 text-purple-300 border border-purple-800">
                          {radarInvestResult.disasterPotentials?.earthquake || radarInvestResult.hazardPotentials?.find(h => h.hazard.includes('Gempa'))?.risk || 'Rendah'}
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between text-[11px] font-bold text-slate-200">
                        <span>🔥 Kebakaran Hutan / Lahan (Karhutla)</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-orange-950 text-orange-300 border border-orange-800">
                          {radarInvestResult.disasterPotentials?.wildfire || radarInvestResult.hazardPotentials?.find(h => h.hazard.includes('Karhutla'))?.risk || 'Nihil'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Rekomendasi Teknis Pengembang */}
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-emerald-400" />
                    <span>REKOMENDASI TEKNIS & MITIGASI INVESTOR</span>
                  </h4>

                  <ul className="space-y-2">
                    {(radarInvestResult.technicalMitigation || radarInvestResult.mitigationNotes || []).map((item, idx) => (
                      <li key={idx} className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[11px] text-slate-300 flex items-start gap-2">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              /* State when no analysis has been run yet */
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 text-center space-y-4">
                <div className="w-12 h-12 bg-emerald-950/80 border border-emerald-800 rounded-full flex items-center justify-center mx-auto text-emerald-400">
                  <Briefcase className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">Analitik Radar Invest (Dunia Usaha)</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Belum ada analisis koordinat aktif. Buka tab <span className="text-emerald-400 font-bold">"Invest"</span> di panel sebelah kiri untuk memasukkan titik koordinat (X, Y) lokasi rencana pembangunan Anda.
                  </p>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* AI Risk Report View */
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-amber-500/30 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                  <Sparkles className="w-4 h-4" />
                  <span>Gemini 2.5 Flash Risk Assessment</span>
                </div>
                <span className="text-[9px] bg-amber-950/80 text-amber-300 px-2 py-0.5 rounded font-mono border border-amber-800">
                  REAL-TIME AI
                </span>
              </div>

              {isAiLoading ? (
                <div className="py-8 text-center space-y-2">
                  <span className="w-6 h-6 border-2 border-amber-400 border-t-transparent rounded-full animate-spin inline-block"></span>
                  <p className="text-xs text-slate-400 font-mono">Memproses raster GEE & menghasilkan rekomendasi BPBD...</p>
                </div>
              ) : aiAssessment ? (
                <div className="space-y-3 text-xs">
                  {/* Executive Summary */}
                  <div>
                    <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Ringkasan Eksekutif Satelit GEE</span>
                    </h4>
                    <p className="text-slate-300 text-[11px] leading-relaxed bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
                      {aiAssessment.executiveSummary}
                    </p>
                  </div>

                  {/* Vulnerabilities */}
                  <div>
                    <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                      <span>Faktor Kerentanan Utama</span>
                    </h4>
                    <ul className="space-y-1 pl-1">
                      {aiAssessment.vulnerabilityFactors.map((v, i) => (
                        <li key={i} className="text-slate-300 text-[11px] flex items-start gap-1.5">
                          <span className="text-amber-400 font-bold">•</span>
                          <span>{v}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Immediate Action Plan */}
                  <div>
                    <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
                      <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                      <span>Rencana Aksi Tanggap Darurat BPBD</span>
                    </h4>
                    <ul className="space-y-1 pl-1">
                      {aiAssessment.immediateActionPlan.map((action, i) => (
                        <li key={i} className="text-slate-300 text-[11px] flex items-start gap-1.5">
                          <span className="text-rose-400 font-bold">{i + 1}.</span>
                          <span>{action}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Emergency Hotline */}
                  <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-center font-mono">
                    <span className="text-[10px] text-slate-400 block">Protokol Kontak Darurat:</span>
                    <span className="text-xs font-bold text-emerald-400">{aiAssessment.emergencyContactProtocol}</span>
                  </div>
                </div>
              ) : (
                <div className="py-6 text-center space-y-3">
                  <p className="text-xs text-slate-400">Klik tombol di bawah untuk meminta Gemini AI menganalisis statistik raster GEE untuk {districtName}.</p>
                  <button
                    onClick={onRequestAiAnalysis}
                    className="py-2 px-4 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs rounded-lg shadow-lg shadow-emerald-950/50 transition-all inline-flex items-center gap-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Jalankan Analisis AI BPBD</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};

