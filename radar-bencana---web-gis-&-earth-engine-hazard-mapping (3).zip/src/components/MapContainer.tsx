import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { 
  Maximize2, 
  Layers, 
  RotateCcw, 
  Eye, 
  EyeOff, 
  Share2, 
  Camera, 
  Box, 
  Grid, 
  Map, 
  ChevronDown,
  Info,
  Calendar,
  Compass,
  Play,
  Pause,
  MapPin,
  AlertTriangle,
  Users,
  Home,
  ShieldAlert,
  Clock,
  Filter,
  Building2,
  Flame,
  ListFilter
} from 'lucide-react';
import { AdminFeatureCollection, AdminFeature, AdminProperties, HazardType, DisasterIncident, FacilityCategory, FacilitySubType, RadarInvestResult } from '../types';
import { HAZARD_LAYERS } from '../data/hazardLayers';
import { DISASTER_INCIDENTS } from '../data/mockDisasterIncidents';
import { MOCK_FACILITIES } from '../data/mockFacilities';
import { POLA_RUANG_DATA } from '../data/mockPolaRuang';

interface MapContainerProps {
  adminBoundaries: AdminFeatureCollection;
  selectedDistrict: AdminFeature | null;
  onSelectDistrict: (district: AdminFeature | null) => void;
  selectedHazard: HazardType;
  showHazardLayer?: boolean;
  onToggleHazardLayer?: () => void;
  hazardRenderMode?: 'class' | 'index';
  onChangeHazardRenderMode?: (mode: 'class' | 'index') => void;
  opacity: number;
  showAdminBoundaries: boolean;
  showPolaRuang?: boolean;
  showIncidents: boolean;
  onToggleIncidents: () => void;
  selectedIncidentHazards: HazardType[];
  showFacilities: boolean;
  onToggleFacilities: () => void;
  selectedFacilityCategories: FacilityCategory[];
  selectedFacilitySubTypes: FacilitySubType[];
  mapTileUrlPattern?: string;
  isMapLoading: boolean;
  onResetView: () => void;
  radarInvestResult?: RadarInvestResult | null;
  isPickingOnMap?: boolean;
  onMapClickSelect?: (lat: number, lng: number) => void;
  onCancelPickOnMap?: () => void;
  showAllIncidentsMode?: boolean;
  onToggleAllIncidentsMode?: () => void;
  onOpenAllIncidentsModal?: () => void;
  focusedCoords?: [number, number] | null;
  customUploadedLayers?: any[];
}

export const MapContainer: React.FC<MapContainerProps> = ({
  adminBoundaries,
  selectedDistrict,
  onSelectDistrict,
  selectedHazard,
  showHazardLayer = true,
  onToggleHazardLayer,
  hazardRenderMode = 'class',
  onChangeHazardRenderMode,
  opacity,
  showAdminBoundaries,
  showPolaRuang = true,
  showIncidents,
  onToggleIncidents,
  selectedIncidentHazards,
  showFacilities,
  onToggleFacilities,
  selectedFacilityCategories,
  selectedFacilitySubTypes,
  mapTileUrlPattern,
  isMapLoading,
  onResetView,
  radarInvestResult,
  isPickingOnMap = false,
  onMapClickSelect,
  onCancelPickOnMap,
  showAllIncidentsMode = false,
  onToggleAllIncidentsMode,
  onOpenAllIncidentsModal,
  focusedCoords = null,
  customUploadedLayers = [],
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<L.Map | null>(null);
  const geojsonLayerRef = useRef<L.GeoJSON | null>(null);
  const polaRuangLayerRef = useRef<L.GeoJSON | null>(null);
  const rasterCanvasOverlayRef = useRef<L.ImageOverlay | null>(null);
  const incidentsLayerRef = useRef<L.LayerGroup | null>(null);
  const facilitiesLayerRef = useRef<L.LayerGroup | null>(null);
  const investLayerRef = useRef<L.LayerGroup | null>(null);
  const customUploadedLayerGroupRef = useRef<L.LayerGroup | null>(null);


  const [mouseCoords, setMouseCoords] = useState<{ lat: number; lng: number }>({
    lat: -6.81482,
    lng: 107.60851,
  });
  const [selectedYear, setSelectedYear] = useState<number>(2024);
  const [basemapStyle, setBasemapStyle] = useState<'google_hybrid' | 'google_satellite' | 'osm' | 'dark' | 'esri_satellite'>('google_hybrid');
  const [showLegend, setShowLegend] = useState<boolean>(true);
  const [groupingMode, setGroupingMode] = useState<string>('Wilayah / Kabupaten');
  const [isPlayingTimelapse, setIsPlayingTimelapse] = useState<boolean>(false);
  const [isTimelineVisible, setIsTimelineVisible] = useState<boolean>(true);
  const [isScaleVisible, setIsScaleVisible] = useState<boolean>(true);

  // Automated Timelapse Player Loop
  useEffect(() => {
    let timer: any = null;
    if (isPlayingTimelapse) {
      timer = setInterval(() => {
        setSelectedYear((prev) => (prev >= 2025 ? 2018 : prev + 1));
      }, 1800);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isPlayingTimelapse]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapRef.current || leafletMap.current) return;

    // West Java center coordinates
    const map = L.map(mapRef.current, {
      center: [-6.85, 107.50],
      zoom: 9,
      zoomControl: false,
      attributionControl: false,
    });

    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // Mouse move coordinate listener
    map.on('mousemove', (e: L.LeafletMouseEvent) => {
      setMouseCoords({
        lat: Number(e.latlng.lat.toFixed(6)),
        lng: Number(e.latlng.lng.toFixed(6)),
      });
    });

    leafletMap.current = map;

    return () => {
      map.remove();
      leafletMap.current = null;
    };
  }, []);

  // Focus map on specific coordinates when selected from All Disaster Incidents Modal
  useEffect(() => {
    if (focusedCoords && leafletMap.current) {
      leafletMap.current.flyTo(focusedCoords, 13, { animate: true, duration: 1.5 });
    }
  }, [focusedCoords]);

  // Map Click Listener for "Pilih Berdasarkan Peta" mode
  useEffect(() => {
    if (!leafletMap.current) return;
    const map = leafletMap.current;

    const handleMapClick = (e: L.LeafletMouseEvent) => {
      if (isPickingOnMap && onMapClickSelect) {
        onMapClickSelect(e.latlng.lat, e.latlng.lng);
      }
    };

    if (isPickingOnMap) {
      map.on('click', handleMapClick);
      if (mapRef.current) {
        mapRef.current.style.cursor = 'crosshair';
      }
    } else {
      if (mapRef.current) {
        mapRef.current.style.cursor = '';
      }
    }

    return () => {
      map.off('click', handleMapClick);
      if (mapRef.current) {
        mapRef.current.style.cursor = '';
      }
    };
  }, [isPickingOnMap, onMapClickSelect]);

  // Update Basemap Tiles
  useEffect(() => {
    if (!leafletMap.current) return;
    const map = leafletMap.current;

    // Remove existing tile layers
    map.eachLayer((layer) => {
      if (layer instanceof L.TileLayer) {
        map.removeLayer(layer);
      }
    });

    let url = 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}';
    let subdomains: string | string[] = ['mt0', 'mt1', 'mt2', 'mt3'];
    let maxZoom = 20;

    if (basemapStyle === 'google_satellite') {
      url = 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}';
      subdomains = ['mt0', 'mt1', 'mt2', 'mt3'];
      maxZoom = 20;
    } else if (basemapStyle === 'google_hybrid') {
      url = 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}';
      subdomains = ['mt0', 'mt1', 'mt2', 'mt3'];
      maxZoom = 20;
    } else if (basemapStyle === 'osm') {
      url = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
      subdomains = ['a', 'b', 'c'];
      maxZoom = 19;
    } else if (basemapStyle === 'esri_satellite') {
      url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
      subdomains = 'abcd';
      maxZoom = 19;
    } else if (basemapStyle === 'dark') {
      url = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
      subdomains = 'abcd';
      maxZoom = 19;
    }

    L.tileLayer(url, { maxZoom, subdomains }).addTo(map);
  }, [basemapStyle]);

  // Render Admin Vector Layer
  useEffect(() => {
    if (!leafletMap.current) return;
    const map = leafletMap.current;

    if (geojsonLayerRef.current) {
      map.removeLayer(geojsonLayerRef.current);
      geojsonLayerRef.current = null;
    }

    if (!showAdminBoundaries) return;

    const layer = L.geoJSON(adminBoundaries as any, {
      style: (feature) => {
        const isSelected = selectedDistrict && selectedDistrict.id === feature?.id;
        return {
          color: isSelected ? '#10b981' : '#64748b',
          weight: isSelected ? 3 : 1.2,
          opacity: isSelected ? 1.0 : 0.7,
          fillColor: isSelected ? '#10b981' : '#1e293b',
          fillOpacity: isSelected ? 0.25 : 0.05,
          dashArray: isSelected ? '' : '3, 3',
        };
      },
      onEachFeature: (feature, polygonLayer) => {
        const props = feature.properties as AdminProperties;
        const tinggi = props.luas_risiko_tinggi_ha || Math.round(props.total_area_ha * 0.35);
        const sedang = props.luas_risiko_sedang_ha || Math.round(props.total_area_ha * 0.40);
        const rendah = props.luas_risiko_rendah_ha || Math.max(0, props.total_area_ha - tinggi - sedang);

        polygonLayer.bindTooltip(
          `
          <div class="p-1 font-sans">
            <div class="font-bold text-slate-100 text-xs">${props.name}</div>
            <div class="text-[10px] text-slate-300 font-mono">${props.type} • ${props.total_area_ha.toLocaleString()} ha</div>
            <div class="text-[9px] text-rose-400 font-mono">Tinggi: ${tinggi.toLocaleString()} Ha | Sedang: ${sedang.toLocaleString()} Ha</div>
          </div>
          `,
          { sticky: true, direction: 'top' }
        );

        polygonLayer.bindPopup(
          `
          <div class="p-2.5 font-sans w-72 max-w-[290px] text-slate-100 bg-slate-900/95 rounded-xl border border-slate-800 shadow-2xl backdrop-blur">
            <div class="flex items-center justify-between gap-1 mb-2 pb-1.5 border-b border-slate-800">
              <span class="px-2 py-0.5 text-[10px] font-mono font-bold rounded uppercase tracking-wider bg-emerald-950 text-emerald-300 border border-emerald-800">
                ${props.code} • Batas Administrasi
              </span>
              <span class="text-[9px] font-mono text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">${props.province}</span>
            </div>

            <h4 class="font-bold text-xs text-slate-100 mb-2 leading-snug">${props.name}</h4>

            <div class="bg-slate-950 p-2 rounded-lg border border-slate-800/80 mb-2 space-y-1 text-[10px]">
              <div class="flex justify-between border-b border-slate-900 pb-1">
                <span class="text-slate-400 font-mono">Luas Total:</span>
                <span class="font-bold text-slate-200 font-mono">${props.total_area_ha.toLocaleString()} Ha</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400 font-mono">Populasi:</span>
                <span class="font-medium text-slate-300">${props.population.toLocaleString()} jiwa</span>
              </div>
            </div>

            <div class="bg-slate-950 p-2 rounded-lg border border-slate-800/80 mb-2 space-y-1.5">
              <div class="text-[9px] font-mono font-bold uppercase tracking-wider text-amber-400 flex items-center justify-between">
                <span>Rincian Luasan Kelas Bencana (Ha):</span>
              </div>

              <div class="space-y-1 text-[10px] font-mono">
                <div class="flex items-center justify-between p-1 rounded bg-rose-950/40 border border-rose-900/50">
                  <span class="text-rose-300 font-semibold flex items-center gap-1">
                    <span class="w-2 h-2 rounded-full bg-rose-500"></span> Kelas Tinggi:
                  </span>
                  <span class="font-bold text-rose-200">${tinggi.toLocaleString()} Ha</span>
                </div>

                <div class="flex items-center justify-between p-1 rounded bg-amber-950/40 border border-amber-900/50">
                  <span class="text-amber-300 font-semibold flex items-center gap-1">
                    <span class="w-2 h-2 rounded-full bg-amber-500"></span> Kelas Sedang:
                  </span>
                  <span class="font-bold text-amber-200">${sedang.toLocaleString()} Ha</span>
                </div>

                <div class="flex items-center justify-between p-1 rounded bg-emerald-950/40 border border-emerald-900/50">
                  <span class="text-emerald-300 font-semibold flex items-center gap-1">
                    <span class="w-2 h-2 rounded-full bg-emerald-500"></span> Kelas Rendah:
                  </span>
                  <span class="font-bold text-emerald-200">${rendah.toLocaleString()} Ha</span>
                </div>
              </div>
            </div>

            <div class="text-[9px] text-slate-400 leading-tight">
              Kerentanan Utama: <span class="text-slate-200 font-medium">${props.primary_vulnerability}</span>
            </div>
          </div>
          `,
          { closeButton: true }
        );

        polygonLayer.on('click', (e) => {
          L.DomEvent.stopPropagation(e);
          onSelectDistrict(feature as AdminFeature);

          // Zoom to polygon bounds
          if (polygonLayer instanceof L.Polygon) {
            map.fitBounds(polygonLayer.getBounds(), { padding: [50, 50], maxZoom: 11 });
          }
        });
      },
    }).addTo(map);

    geojsonLayerRef.current = layer;
  }, [adminBoundaries, selectedDistrict, showAdminBoundaries, onSelectDistrict]);

  // Render Pola Ruang RTRW Vector Layer
  useEffect(() => {
    if (!leafletMap.current) return;
    const map = leafletMap.current;

    if (polaRuangLayerRef.current) {
      map.removeLayer(polaRuangLayerRef.current);
      polaRuangLayerRef.current = null;
    }

    if (!showPolaRuang) return;

    const layer = L.geoJSON(POLA_RUANG_DATA as any, {
      style: (feature) => {
        const color = feature?.properties?.color || '#0d9488';
        return {
          color: color,
          weight: 2,
          opacity: 0.85,
          fillColor: color,
          fillOpacity: 0.3,
          dashArray: '4, 4',
        };
      },
      onEachFeature: (feature, polygonLayer) => {
        const props = feature.properties;
        const isLindung = props.kategori_utama === 'Kawasan Lindung';
        const badgeColorClass = isLindung 
          ? 'bg-emerald-950 text-emerald-300 border-emerald-800' 
          : 'bg-purple-950 text-purple-300 border-purple-800';

        polygonLayer.bindTooltip(
          `
          <div class="p-1 font-sans">
            <div class="font-bold text-slate-100 text-xs">${props.kode_zona} - ${props.nama_zona}</div>
            <div class="text-[10px] text-teal-300 font-mono">${props.kategori_utama} • ${props.luas_ha.toLocaleString()} ha</div>
          </div>
          `,
          { sticky: true, direction: 'top' }
        );

        polygonLayer.bindPopup(
          `
          <div class="p-2.5 font-sans w-72 max-w-[290px] text-slate-100 bg-slate-900/95 rounded-xl border border-slate-800 shadow-2xl backdrop-blur">
            <div class="flex items-center justify-between gap-1 mb-2 pb-1.5 border-b border-slate-800">
              <span class="px-2 py-0.5 text-[10px] font-mono font-bold rounded uppercase tracking-wider border ${badgeColorClass}">
                ${props.kode_zona} • ${props.kategori_utama}
              </span>
              <span class="text-[9px] font-mono text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">${props.id_pola_ruang}</span>
            </div>

            <h4 class="font-bold text-xs text-slate-100 mb-2 leading-snug">${props.nama_zona}</h4>

            <div class="bg-slate-950 p-2 rounded-lg border border-slate-800/80 mb-2 space-y-1 text-[10px]">
              <div class="flex justify-between border-b border-slate-900 pb-1">
                <span class="text-slate-500 font-mono">Kab/Kota:</span>
                <span class="font-semibold text-slate-200">${props.kabupaten_kota}</span>
              </div>
              <div class="flex justify-between border-b border-slate-900 pb-1">
                <span class="text-slate-500 font-mono">Luas Area:</span>
                <span class="font-semibold text-teal-300 font-mono">${props.luas_ha.toLocaleString()} Ha</span>
              </div>
              <div class="flex justify-between pt-0.5">
                <span class="text-slate-500 font-mono">Sub-Zona:</span>
                <span class="font-medium text-slate-300 text-right shrink-0 max-w-[150px] truncate">${props.sub_zona_pola_ruang}</span>
              </div>
            </div>

            <div class="bg-slate-950 p-2 rounded-lg border border-slate-800/80 mb-2 space-y-1">
              <div class="text-[8px] font-mono font-bold uppercase tracking-wider text-amber-400">
                📋 Ketentuan KKPR (Dinas PUPR)
              </div>
              <p class="text-[10px] text-slate-200 leading-snug font-sans">${props.ketentuan_kkpr}</p>
            </div>

            <div class="flex items-center justify-between pt-1 border-t border-slate-800 text-[9px] font-mono">
              <span class="text-slate-400">Status: <strong class="text-amber-300">${props.status_konservasi}</strong></span>
            </div>
          </div>
          `,
          { closeButton: true }
        );

        polygonLayer.on('click', (e) => {
          L.DomEvent.stopPropagation(e);
          if (polygonLayer instanceof L.Polygon) {
            map.fitBounds(polygonLayer.getBounds(), { padding: [40, 40], maxZoom: 12 });
          }
        });
      },
    }).addTo(map);

    polaRuangLayerRef.current = layer;
  }, [showPolaRuang]);

  // Render Simulated GEE Hazard Raster Overlay (Clipped to selected district or region)
  useEffect(() => {
    if (!leafletMap.current) return;
    const map = leafletMap.current;

    if (rasterCanvasOverlayRef.current) {
      map.removeLayer(rasterCanvasOverlayRef.current);
      rasterCanvasOverlayRef.current = null;
    }

    // If hazard layer is toggled off, do not draw overlay
    if (!showHazardLayer) return;

    // Generate Canvas Heatmap / Raster simulation matching GEE tile output
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 600;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      const palette = HAZARD_LAYERS[selectedHazard].colorPalette;
      const colors = [palette.low, palette.medium, palette.high];

      // Draw grid raster cells to simulate GEE 30m resolution pixels
      const cols = 60;
      const rows = 60;
      const cellW = canvas.width / cols;
      const cellH = canvas.height / rows;

      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          // Perlin-like pseudo noise calculation
          const nx = c / cols - 0.5;
          const ny = r / rows - 0.5;
          const dist = Math.sqrt(nx * nx + ny * ny);

          if (dist > 0.48) continue; // Boundary cutout

          let val = Math.sin(c * 0.15) * Math.cos(r * 0.15);
          if (selectedHazard === 'flood') val += (r / rows) * 0.8;
          if (selectedHazard === 'landslide') val += (c / cols) * 0.9;

          // Normalized index between 0.0 and 1.0
          let indexVal = (val + 0.8) / 2.6;
          indexVal = Math.max(0.0, Math.min(1.0, indexVal));

          if (hazardRenderMode === 'class') {
            // Discrete classes: 1 = Rendah, 2 = Sedang, 3 = Tinggi
            let colorIdx = 0; // 0 = Rendah (Class 1)
            if (indexVal > 0.58) colorIdx = 2; // 2 = Tinggi (Class 3)
            else if (indexVal > 0.30) colorIdx = 1; // 1 = Sedang (Class 2)

            ctx.fillStyle = colors[colorIdx];
          } else {
            // Continuous Smooth Gradient: Hijau (16, 185, 129) -> Kuning (245, 158, 11) -> Merah (244, 63, 94)
            let rG: number, gG: number, bG: number;
            if (indexVal <= 0.5) {
              const t = indexVal / 0.5;
              rG = Math.round(16 + t * (245 - 16));
              gG = Math.round(185 + t * (158 - 185));
              bG = Math.round(129 + t * (11 - 129));
            } else {
              const t = (indexVal - 0.5) / 0.5;
              rG = Math.round(245 + t * (244 - 245));
              gG = Math.round(158 + t * (63 - 158));
              bG = Math.round(11 + t * (94 - 11));
            }
            ctx.fillStyle = `rgb(${rG}, ${gG}, ${bG})`;
          }

          ctx.fillRect(c * cellW, r * cellH, cellW - 0.5, cellH - 0.5);
        }
      }

      // Determine bounding box (Clipped vs Regional)
      let bounds: L.LatLngBoundsExpression = [
        [-7.70, 106.35],
        [-6.25, 108.80],
      ];

      if (selectedDistrict) {
        const coords = selectedDistrict.geometry.coordinates[0];
        let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
        coords.forEach(([lng, lat]: [number, number]) => {
          if (lat < minLat) minLat = lat;
          if (lat > maxLat) maxLat = lat;
          if (lng < minLng) minLng = lng;
          if (lng > maxLng) maxLng = lng;
        });
        bounds = [
          [minLat, minLng],
          [maxLat, maxLng],
        ];
      }

      const overlayUrl = canvas.toDataURL();
      const overlay = L.imageOverlay(overlayUrl, bounds, {
        opacity: opacity,
        interactive: false,
      }).addTo(map);

      rasterCanvasOverlayRef.current = overlay;
    }
  }, [selectedHazard, selectedDistrict, opacity, showHazardLayer, hazardRenderMode]);

  // Render Interactive Disaster Incident Markers (Titik Bencana)
  useEffect(() => {
    if (!leafletMap.current) return;
    const map = leafletMap.current;

    if (incidentsLayerRef.current) {
      map.removeLayer(incidentsLayerRef.current);
      incidentsLayerRef.current = null;
    }

    if (!showIncidents) return;

    const layerGroup = L.layerGroup();

    // Filter incidents matching selectedYear and selectedIncidentHazards
    const filteredIncidents = DISASTER_INCIDENTS.filter((inc) => {
      if (showAllIncidentsMode) return true; // Show ALL disaster incidents overall across all years & types
      const matchYear = inc.year === selectedYear;
      const matchHazardType = selectedIncidentHazards.includes(inc.hazardType);
      return matchYear && matchHazardType;
    });

    filteredIncidents.forEach((incident) => {
      const hazardColor = 
        incident.hazardType === 'flood' ? '#3b82f6' :
        incident.hazardType === 'landslide' ? '#f97316' :
        incident.hazardType === 'wildfire' ? '#ef4444' : '#06b6d4';

      const hazardBadgeText =
        incident.hazardType === 'flood' ? 'Banjir' :
        incident.hazardType === 'landslide' ? 'Longsor' :
        incident.hazardType === 'wildfire' ? 'Karhutla' : 'Gelombang/Coastal';

      // Custom HTML Pin Icon with pulsing ring
      const customIcon = L.divIcon({
        className: 'custom-disaster-pin',
        html: `
          <div class="relative group cursor-pointer">
            <span class="absolute -inset-1 rounded-full animate-ping opacity-75" style="background-color: ${hazardColor};"></span>
            <div class="relative w-8 h-8 rounded-full flex items-center justify-center text-white shadow-xl border-2 border-slate-900 font-bold" style="background-color: ${hazardColor};">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
              </svg>
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const marker = L.marker(incident.coordinates, { icon: customIcon });

      const popupContent = `
        <div class="p-2.5 font-sans w-64 max-w-[260px] text-slate-100 bg-slate-900/95 rounded-xl border border-slate-800 shadow-2xl backdrop-blur">
          <div class="flex items-center justify-between gap-1 mb-1.5 pb-1 border-b border-slate-800">
            <div class="flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full animate-pulse" style="background-color: ${hazardColor};"></span>
              <span class="px-1.5 py-0.5 text-[9px] font-mono font-bold rounded uppercase tracking-wider" style="background-color: ${hazardColor}20; color: ${hazardColor}; border: 1px solid ${hazardColor}40;">
                ${hazardBadgeText}
              </span>
            </div>
            <span class="text-[9px] font-mono text-slate-400 bg-slate-800 px-1 py-0.5 rounded">${incident.date}</span>
          </div>

          <h4 class="font-bold text-[11px] text-slate-100 mb-1.5 leading-snug">${incident.title}</h4>

          <!-- ALAMAT & LOKASI KEJADIAN BENCANA -->
          <div class="bg-slate-950 p-2 rounded-lg border border-slate-800/80 mb-1.5 space-y-0.5 text-[10px]">
            <div class="text-[8px] font-mono font-bold uppercase tracking-wider text-rose-400 mb-0.5 flex items-center gap-1">
              <span>📍 ALAMAT & LOKASI KEJADIAN</span>
            </div>
            <div class="flex items-start justify-between gap-2 text-slate-200">
              <span class="text-slate-500 font-mono shrink-0">Desa/Kel:</span>
              <span class="font-semibold text-slate-100 text-right truncate">${incident.villageName || '-'}</span>
            </div>
            <div class="flex items-start justify-between gap-2 text-slate-200">
              <span class="text-slate-500 font-mono shrink-0">Kecamatan:</span>
              <span class="font-semibold text-slate-100 text-right truncate">${incident.subdistrictName || '-'}</span>
            </div>
            <div class="flex items-start justify-between gap-2 text-slate-200">
              <span class="text-slate-500 font-mono shrink-0">Kab/Kota:</span>
              <span class="font-semibold text-slate-100 text-right truncate">${incident.districtName}</span>
            </div>
            <div class="flex items-start justify-between gap-2 text-slate-300 text-[9px] border-t border-slate-900 pt-0.5 mt-0.5">
              <span class="text-slate-500 font-mono shrink-0">Titik Detail:</span>
              <span class="text-slate-300 text-right truncate">${incident.locationName}</span>
            </div>
          </div>

          <!-- DAMPAK BENCANA (NARASI) -->
          <div class="bg-slate-950 p-2 rounded-lg border border-slate-800/80 mb-1.5 space-y-1">
            <div class="text-[8px] font-mono font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1">
              <span>💥 DAMPAK BENCANA</span>
            </div>
            
            <p class="text-[10px] text-slate-200 leading-snug font-sans">
              ${incident.description}
            </p>

            ${incident.infrastructureImpact ? `
              <div class="text-[9px] text-slate-300 bg-slate-900/60 p-1.5 rounded border border-slate-800/60 leading-snug mt-1">
                <span class="text-amber-400 font-mono text-[8px] block mb-0.5 font-bold uppercase tracking-wider">Infrastruktur & Fasilitas:</span>
                <span class="text-slate-200 font-medium">${incident.infrastructureImpact}</span>
              </div>
            ` : ''}
          </div>
          
          <div class="flex items-center justify-between pt-1 border-t border-slate-800 text-[9px] font-mono">
            <span class="text-slate-400">Status: <strong class="text-emerald-400">${incident.status}</strong></span>
            <span class="px-1 py-0.5 rounded text-[8px] uppercase font-bold text-rose-300 bg-rose-950/80 border border-rose-800">${incident.severity}</span>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent, {
        className: 'custom-leaflet-popup',
        maxWidth: 270,
      });

      marker.on('click', () => {
        marker.openPopup();
      });

      layerGroup.addLayer(marker);
    });

    layerGroup.addTo(map);
    incidentsLayerRef.current = layerGroup;

    // Smooth camera fly to the incident location(s) of the active year during timelapse
    if (filteredIncidents.length > 0) {
      if (filteredIncidents.length === 1) {
        const coords = filteredIncidents[0].coordinates;
        map.flyTo(coords, 11, { duration: 1.2, animate: true });
      } else {
        const bounds = L.latLngBounds(filteredIncidents.map((inc) => inc.coordinates));
        map.flyToBounds(bounds, { maxZoom: 12, padding: [80, 80], duration: 1.2, animate: true });
      }
    }
  }, [showIncidents, selectedYear, selectedIncidentHazards, showAllIncidentsMode]);

  // Render Facilities Layer (Fasilitas Kritis & Fasilitas Umum)
  useEffect(() => {
    const map = leafletMap.current;
    if (!map) return;

    if (facilitiesLayerRef.current) {
      map.removeLayer(facilitiesLayerRef.current);
      facilitiesLayerRef.current = null;
    }

    if (!showFacilities) return;

    const layerGroup = L.layerGroup();

    const filteredFacilities = MOCK_FACILITIES.filter((fac) => {
      const categoryMatch = selectedFacilityCategories.includes(fac.category);
      const subTypeMatch = selectedFacilitySubTypes.includes(fac.subType);

      let districtMatch = true;
      if (selectedDistrict) {
        const districtName = selectedDistrict.properties.name.toLowerCase().replace(/^(kabupaten|kota)\s+/, '');
        const facDistrictName = fac.districtName.toLowerCase().replace(/^(kabupaten|kota)\s+/, '');
        districtMatch = facDistrictName.includes(districtName) || districtName.includes(facDistrictName);
      }

      return categoryMatch && subTypeMatch && districtMatch;
    });

    const subTypeIcons: Record<FacilitySubType, string> = {
      'Rumah Sakit': '🏥',
      'Posko BPBD': '🛡️',
      'Pemadam': '🚒',
      'Polisi': '🚔',
      'Sekolah / Pengungsian': '🏫',
      'Tempat Ibadah': '🕌',
      'Pasar / Logistik': '📦',
      'Gedung Olahraga': '🏟️',
    };

    filteredFacilities.forEach((fac) => {
      const isKritis = fac.category === 'kritis';
      const themeColor = isKritis ? '#10b981' : '#3b82f6';
      const badgeText = isKritis ? 'Fasilitas Kritis' : 'Fasilitas Umum';
      const badgeClass = isKritis
        ? 'text-emerald-400 bg-emerald-950/80 border-emerald-800'
        : 'text-blue-400 bg-blue-950/80 border-blue-800';

      const iconSymbol = subTypeIcons[fac.subType] || (isKritis ? '🏥' : '🏫');

      const customIcon = L.divIcon({
        className: 'custom-facility-pin',
        html: `
          <div class="relative group cursor-pointer">
            <div class="w-7 h-7 rounded-lg flex items-center justify-center text-xs shadow-lg border-2 border-slate-900 font-bold transition-transform hover:scale-110" style="background-color: ${themeColor};">
              <span>${iconSymbol}</span>
            </div>
          </div>
        `,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      const marker = L.marker(fac.coordinates, { icon: customIcon });

      const popupContent = `
        <div class="p-2.5 font-sans w-64 max-w-[260px] text-slate-100 bg-slate-900/95 rounded-xl border border-slate-800 shadow-2xl backdrop-blur">
          <div class="flex items-center justify-between gap-1 mb-1.5 pb-1 border-b border-slate-800">
            <div class="flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full" style="background-color: ${themeColor};"></span>
              <span class="px-1.5 py-0.5 text-[9px] font-mono font-bold rounded uppercase tracking-wider border ${badgeClass}">
                ${badgeText}
              </span>
            </div>
            <span class="text-[9px] font-mono text-slate-300 bg-slate-800 px-1 py-0.5 rounded">${fac.subType}</span>
          </div>

          <h4 class="font-bold text-[11px] text-slate-100 mb-1.5 leading-snug">${fac.name}</h4>

          <!-- ALAMAT & LOKASI DETAIL -->
          <div class="bg-slate-950 p-2 rounded-lg border border-slate-800/80 mb-1.5 space-y-0.5 text-[10px]">
            <div class="text-[8px] font-mono font-bold uppercase tracking-wider text-emerald-400 mb-0.5 flex items-center gap-1">
              <span>🏢 DETAIL LOKASI</span>
            </div>
            <div class="flex items-start justify-between gap-2 text-slate-200">
              <span class="text-slate-500 font-mono shrink-0">Desa/Kel:</span>
              <span class="font-semibold text-slate-100 text-right truncate">${fac.villageName || '-'}</span>
            </div>
            <div class="flex items-start justify-between gap-2 text-slate-200">
              <span class="text-slate-500 font-mono shrink-0">Kecamatan:</span>
              <span class="font-semibold text-slate-100 text-right truncate">${fac.subdistrictName || '-'}</span>
            </div>
            <div class="flex items-start justify-between gap-2 text-slate-200">
              <span class="text-slate-500 font-mono shrink-0">Kab/Kota:</span>
              <span class="font-semibold text-slate-100 text-right truncate">${fac.districtName}</span>
            </div>
            <div class="flex items-start justify-between gap-2 text-slate-300 text-[9px] border-t border-slate-900 pt-0.5 mt-0.5">
              <span class="text-slate-500 font-mono shrink-0">Jalan:</span>
              <span class="text-slate-300 text-right truncate">${fac.address}</span>
            </div>
          </div>

          <!-- KAPASITAS & KONTAK -->
          <div class="bg-slate-950 p-2 rounded-lg border border-slate-800/80 mb-1.5 space-y-1 text-[9px]">
            <div class="text-[8px] font-mono font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-1">
              <span>ℹ️ KAPASITAS & KONTAK</span>
            </div>
            <p class="text-slate-200 font-medium leading-snug">${fac.capacityInfo || 'Fasilitas pendukung darurat'}</p>
            ${fac.contact ? `
              <div class="text-slate-400 font-mono text-[8px] pt-1 border-t border-slate-900 flex justify-between">
                <span>Kontak:</span>
                <span class="text-emerald-400 font-bold">${fac.contact}</span>
              </div>
            ` : ''}
          </div>

          <div class="flex items-center justify-between pt-1 border-t border-slate-800 text-[9px] font-mono">
            <span class="text-slate-400">Status: <strong class="text-emerald-400">${fac.status}</strong></span>
            <span class="px-1 py-0.5 rounded text-[8px] font-bold text-slate-300 bg-slate-800">${fac.category.toUpperCase()}</span>
          </div>
        </div>
      `;

      marker.bindPopup(popupContent, {
        className: 'custom-leaflet-popup',
        maxWidth: 270,
      });

      marker.on('click', () => {
        marker.openPopup();
      });

      layerGroup.addLayer(marker);
    });

    layerGroup.addTo(map);
    facilitiesLayerRef.current = layerGroup;
  }, [showFacilities, selectedFacilityCategories, selectedFacilitySubTypes, selectedDistrict]);

  // Render Radar Invest Plot Marker & Buffer Circle
  useEffect(() => {
    if (!leafletMap.current) return;
    const map = leafletMap.current;

    if (investLayerRef.current) {
      map.removeLayer(investLayerRef.current);
      investLayerRef.current = null;
    }

    if (!radarInvestResult) return;

    const layerGroup = L.layerGroup().addTo(map);
    investLayerRef.current = layerGroup;

    const { lat, lng, projectName, plotAreaHa, feasibilityStatus, isProtectedZone, areaBreakdown, districtName, villageName } = radarInvestResult;

    // Approximate circle radius in meters from Ha: Area = pi * r^2 => r = sqrt(Area_m2 / pi)
    const areaM2 = plotAreaHa * 10000;
    const radiusMeters = Math.max(80, Math.round(Math.sqrt(areaM2 / Math.PI)));

    const color = feasibilityStatus.includes('ZONA MERAH')
      ? '#ef4444'
      : feasibilityStatus.includes('ZONA KUNING')
      ? '#f59e0b'
      : '#10b981';

    // Plot Area Circle
    const circle = L.circle([lat, lng], {
      color: color,
      fillColor: color,
      fillOpacity: 0.35,
      weight: 3,
      radius: radiusMeters,
    }).addTo(layerGroup);

    // Custom Icon Marker
    const pinHtml = `
      <div class="relative flex items-center justify-center">
        <span class="animate-ping absolute inline-flex h-8 w-8 rounded-full opacity-75" style="background-color: ${color}"></span>
        <div class="relative inline-flex rounded-full h-8 w-8 items-center justify-center text-white font-bold text-xs shadow-lg border-2 border-slate-900" style="background-color: ${color}">
          💼
        </div>
      </div>
    `;

    const icon = L.divIcon({
      html: pinHtml,
      className: 'invest-plot-marker',
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });

    const marker = L.marker([lat, lng], { icon }).addTo(layerGroup);

    const popupContent = `
      <div class="p-2 text-slate-100 font-sans max-w-xs space-y-1.5">
        <div class="text-[10px] text-emerald-400 font-mono font-bold uppercase">📍 RADAR INVEST TAPAK</div>
        <div class="font-bold text-xs text-slate-100">${projectName}</div>
        <div class="text-[10px] text-slate-300 font-mono">📍 ${villageName}, ${districtName}</div>
        <div class="text-[10px] text-slate-400 font-mono">X: ${lng}, Y: ${lat} • ${plotAreaHa} Ha</div>
        <div class="p-1 rounded text-[10px] font-bold text-center" style="background-color: ${color}20; color: ${color}; border: 1px solid ${color}80">
          ${feasibilityStatus}
        </div>
        <div class="text-[10px] text-slate-300 font-mono pt-1 border-t border-slate-800">
          Budi Daya: <b class="text-emerald-400">${areaBreakdown.buildableAreaHa} Ha</b> |
          Lindung: <b class="text-rose-400">${areaBreakdown.protectedAreaHa} Ha</b>
        </div>
      </div>
    `;

    marker.bindPopup(popupContent, { className: 'custom-leaflet-popup' });
    circle.bindPopup(popupContent, { className: 'custom-leaflet-popup' });

    // Fly map smoothly to location
    map.flyTo([lat, lng], 13, { duration: 1.5 });

  }, [radarInvestResult]);

  // Render Super Admin Custom Uploaded Layers (CSV / GeoJSON)
  useEffect(() => {
    if (!leafletMap.current) return;
    const map = leafletMap.current;

    if (customUploadedLayerGroupRef.current) {
      map.removeLayer(customUploadedLayerGroupRef.current);
      customUploadedLayerGroupRef.current = null;
    }

    if (!customUploadedLayers || customUploadedLayers.length === 0) return;

    const layerGroup = L.layerGroup().addTo(map);
    customUploadedLayerGroupRef.current = layerGroup;

    customUploadedLayers.forEach((layer) => {
      if (!layer.content && !layer.spatialAttributes) return;

      const spatialAttrs = layer.spatialAttributes || {};

      if (layer.type === 'geojson') {
        try {
          const geoJsonData = typeof layer.content === 'string' ? JSON.parse(layer.content) : layer.content;
          L.geoJSON(geoJsonData, {
            style: {
              color: layer.category === 'admin_boundary' ? '#10b981' : '#38bdf8',
              weight: 2,
              fillColor: layer.category === 'admin_boundary' ? '#059669' : '#0284c7',
              fillOpacity: 0.35,
            },
            onEachFeature: (feature, l) => {
              const props = feature.properties || {};
              const merged = { ...props, ...spatialAttrs };

              let popupHtml = '';
              if (layer.category === 'admin_boundary' || merged.nama_kabupaten || merged.populasi_terpapar_longsor) {
                const code = merged.code || merged.id || merged.kode_desa || '-';
                const kab = merged.nama_kabupaten || merged.kabupaten || merged.kabupaten_kota || '-';
                const kec = merged.nama_kecamatan || merged.kecamatan || '-';
                const desa = merged.nama_desa || merged.desa || merged.kelurahan || '-';
                const popLongsor = merged.populasi_terpapar_longsor || merged.terpapar_longsor || 0;
                const popBanjir = merged.populasi_terpapar_banjir || merged.terpapar_banjir || 0;
                const popKebakaran = merged.populasi_terpapar_kebakaran || merged.terpapar_kebakaran || 0;
                const popGempa = merged.populasi_terpapar_gempa || merged.terpapar_gempa || 0;
                const totalPop = merged.total_populasi || merged.population || 0;
                const areaHa = merged.luas_wilayah_ha || merged.luas_ha || 0;

                popupHtml = `
                  <div class="p-3 font-sans text-xs text-slate-100 bg-slate-900 rounded-xl border border-slate-800 shadow-2xl space-y-2">
                    <div class="flex items-center justify-between border-b border-slate-800 pb-1.5">
                      <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                        🏛️ SPASIAL ADMINISTRASI
                      </span>
                      <span class="text-[10px] font-mono text-slate-400">ID: ${code}</span>
                    </div>
                    <div class="font-bold text-amber-400 text-sm">${layer.name}</div>
                    <div class="grid grid-cols-2 gap-1 text-[10px] bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <div><span class="text-slate-400">Kabupaten:</span> <b class="text-slate-200 block">${kab}</b></div>
                      <div><span class="text-slate-400">Kecamatan:</span> <b class="text-slate-200 block">${kec}</b></div>
                      <div><span class="text-slate-400">Desa/Kel:</span> <b class="text-slate-200 block">${desa}</b></div>
                      <div><span class="text-slate-400">Luas Area:</span> <b class="text-slate-200 block">${Number(areaHa).toLocaleString('id-ID')} Ha</b></div>
                    </div>
                    <div class="p-2 bg-slate-950/90 rounded-lg border border-rose-900/40 space-y-1">
                      <div class="text-[10px] font-mono font-bold text-rose-400 flex items-center justify-between">
                        <span>⚠️ POPULASI TERPAPAR BENCANA</span>
                        <span>Tot: ${Number(totalPop).toLocaleString('id-ID')} Jiwa</span>
                      </div>
                      <div class="grid grid-cols-2 gap-1 text-[10px] font-mono pt-0.5">
                        <div class="text-amber-300">⛰️ Longsor: <b>${Number(popLongsor).toLocaleString('id-ID')}</b></div>
                        <div class="text-sky-300">🌊 Banjir: <b>${Number(popBanjir).toLocaleString('id-ID')}</b></div>
                        <div class="text-orange-300">🔥 Kebakaran: <b>${Number(popKebakaran).toLocaleString('id-ID')}</b></div>
                        <div class="text-rose-300">🌋 Gempa: <b>${Number(popGempa).toLocaleString('id-ID')}</b></div>
                      </div>
                    </div>
                  </div>
                `;
              } else {
                popupHtml = `<div class="p-2 text-xs font-sans text-slate-100 bg-slate-900 rounded-lg">`;
                popupHtml += `<div class="font-bold text-amber-400 mb-1">📁 Layer Super Admin: ${layer.name}</div>`;
                for (const [key, value] of Object.entries(merged)) {
                  popupHtml += `<div class="text-[10px]"><b class="text-slate-400">${key}:</b> ${value}</div>`;
                }
                popupHtml += `</div>`;
              }

              l.bindPopup(popupHtml, { className: 'custom-leaflet-popup' });
            },
          }).addTo(layerGroup);
        } catch (e) {
          console.error('Failed to render custom geojson layer:', e);
        }
      } else if (layer.type === 'csv') {
        // Parse CSV lines for lat/lng
        const lines = layer.content ? layer.content.trim().split('\n') : [];
        if (lines.length >= 2) {
          const headers = lines[0].split(',').map((h: string) => h.trim().toLowerCase());
          const latIdx = headers.findIndex((h: string) => h === 'lat' || h === 'latitude' || h === 'y');
          const lngIdx = headers.findIndex((h: string) => h === 'lng' || h === 'longitude' || h === 'lon' || h === 'x');
          const nameIdx = headers.findIndex((h: string) => h === 'name' || h === 'nama' || h === 'title' || h === 'title_kejadian');

          if (latIdx !== -1 && lngIdx !== -1) {
            for (let i = 1; i < lines.length; i++) {
              const cols = lines[i].split(',').map((c: string) => c.trim());
              const lat = parseFloat(cols[latIdx]);
              const lng = parseFloat(cols[lngIdx]);
              const name = nameIdx !== -1 ? cols[nameIdx] : `Point ${i}`;

              if (!isNaN(lat) && !isNaN(lng)) {
                const icon = L.divIcon({
                  className: 'custom-admin-marker',
                  html: `
                    <div class="relative flex items-center justify-center">
                      <span class="animate-ping absolute inline-flex h-5 w-5 rounded-full bg-amber-400 opacity-75"></span>
                      <div class="relative inline-flex rounded-full h-5 w-5 items-center justify-center bg-amber-500 text-slate-950 font-black text-[10px] shadow-lg border border-slate-900">
                        ★
                      </div>
                    </div>
                  `,
                  iconSize: [20, 20],
                  iconAnchor: [10, 10],
                });

                const marker = L.marker([lat, lng], { icon }).addTo(layerGroup);
                const popupHtml = `
                  <div class="p-2.5 font-sans text-xs text-slate-100 bg-slate-900 rounded-xl border border-slate-800 shadow-2xl">
                    <div class="text-[9px] font-mono font-bold text-amber-400 uppercase mb-1">📁 DATA ADMIN: ${layer.name}</div>
                    <div class="font-bold text-slate-100 mb-1">${name}</div>
                    <div class="text-[10px] text-slate-400 font-mono">X: ${lng}, Y: ${lat}</div>
                  </div>
                `;
                marker.bindPopup(popupHtml, { className: 'custom-leaflet-popup' });
              }
            }
          }
        }
      } else if (layer.type === 'geotiff' || layer.type === 'tif' || layer.type === 'tiff') {
        // GeoTIFF Hazard Raster Layer rendering on Leaflet
        const bounds: L.LatLngBoundsExpression = [
          [-7.3500, 106.4000], // SW (Jawa Barat hazard region extent)
          [-6.3000, 107.9500]  // NE
        ];

        const isKelas = layer.category === 'kelas_bahaya';
        const rectColor = isKelas ? '#f59e0b' : '#f97316';
        const rectFill = isKelas ? '#ef4444' : '#f59e0b';

        const hazardRasterRect = L.rectangle(bounds, {
          color: rectColor,
          weight: 2,
          dashArray: '6, 6',
          fillColor: rectFill,
          fillOpacity: 0.35,
        }).addTo(layerGroup);

        const popupHtml = `
          <div class="p-3 font-sans text-xs text-slate-100 bg-slate-900 rounded-xl border border-slate-800 shadow-2xl space-y-2">
            <div class="flex items-center gap-2">
              <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950 text-amber-400 border border-amber-800">
                🗺️ RASTER GEOTIFF (.TIF)
              </span>
            </div>
            <div class="font-bold text-emerald-400 text-sm">${layer.name}</div>
            <div class="text-[11px] text-slate-300 font-mono">File: ${layer.filename}</div>
            <div class="p-2 bg-slate-950 rounded-lg text-[10px] font-mono text-slate-400 space-y-1">
              <div>Kategori: <b>${layer.category}</b></div>
              <div>Proyeksi: <b>EPSG:4326 (WGS 84)</b></div>
              <div>Status: <b class="text-emerald-400">Raster Overlay Aktif di Peta</b></div>
            </div>
          </div>
        `;
        hazardRasterRect.bindPopup(popupHtml, { className: 'custom-leaflet-popup' });
      }
    });
  }, [customUploadedLayers]);

  return (

    <div className="relative flex-1 h-[calc(100vh-3.5rem)] bg-slate-950 overflow-hidden">
      {/* Map Element */}
      <div ref={mapRef} className="w-full h-full z-0" />

      {/* Floating Active Banner when Point Picker is Active */}
      {isPickingOnMap && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[1000] bg-slate-900/95 border-2 border-emerald-500/90 rounded-2xl px-5 py-3 shadow-2xl flex items-center gap-4 backdrop-blur-md animate-pulse">
          <div className="w-3.5 h-3.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
          <div className="text-xs font-sans">
            <span className="font-extrabold text-emerald-400 block text-xs tracking-wider">MODE PILIH KOORDINAT TAPAK</span>
            <span className="text-slate-200 text-[11px]">Klik di mana saja pada peta untuk menentukan lokasi proyek usaha</span>
          </div>
          <button
            onClick={onCancelPickOnMap}
            className="ml-2 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-bold transition-all shrink-0"
          >
            Batal
          </button>
        </div>
      )}

      {/* Floating Top Left Legend Panel */}
      <div className="absolute top-4 left-4 z-20 bg-slate-900/95 border border-slate-800 rounded-xl shadow-2xl p-3 w-64 backdrop-blur-md">
        <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span className="text-xs font-bold text-slate-100 uppercase tracking-wider">Legenda Hazard</span>
          </div>
          <button
            onClick={() => setShowLegend(!showLegend)}
            className="text-slate-400 hover:text-slate-200 text-xs"
          >
            {showLegend ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </button>
        </div>

        {showLegend && (
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between text-[11px] font-semibold text-emerald-400 font-mono">
              <span>{HAZARD_LAYERS[selectedHazard].name}</span>
              <span className="text-[10px] text-slate-400">
                {showHazardLayer ? (hazardRenderMode === 'class' ? 'Kelas (1-3)' : 'Indeks (0-1)') : 'Mati'}
              </span>
            </div>

            {!showHazardLayer ? (
              <div className="py-2 px-2.5 bg-slate-950/80 rounded border border-slate-800 text-[11px] text-slate-400 italic text-center">
                Layer Bahaya Bencana Non-aktif
              </div>
            ) : hazardRenderMode === 'class' ? (
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded shrink-0" style={{ backgroundColor: HAZARD_LAYERS[selectedHazard].colorPalette.high }}></span>
                  <span className="text-slate-200 text-[11px]">3 - Tinggi (High Vulnerability)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded shrink-0" style={{ backgroundColor: HAZARD_LAYERS[selectedHazard].colorPalette.medium }}></span>
                  <span className="text-slate-200 text-[11px]">2 - Sedang (Moderate Hazard)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded shrink-0" style={{ backgroundColor: HAZARD_LAYERS[selectedHazard].colorPalette.low }}></span>
                  <span className="text-slate-200 text-[11px]">1 - Rendah (Low Danger)</span>
                </div>
              </div>
            ) : (
              <div className="space-y-1 pt-1">
                <div className="h-3 rounded bg-gradient-to-r from-[#10b981] via-[#f59e0b] to-[#f43f5e] border border-slate-700/50 shadow-inner" />
                <div className="flex justify-between text-[9px] font-mono">
                  <span className="text-emerald-400 font-bold">0.0 (Rendah)</span>
                  <span className="text-amber-400 font-bold">0.5 (Sedang)</span>
                  <span className="text-rose-400 font-bold">1.0 (Tinggi)</span>
                </div>
              </div>
            )}

            {/* Incident Toggle Status in Legend */}
            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono">
              <button
                onClick={onToggleIncidents}
                className="flex items-center gap-1.5 text-rose-400 hover:underline"
              >
                <MapPin className="w-3 h-3" />
                <span>{showIncidents ? 'Titik Bencana: Aktif' : 'Titik Bencana: Mati'}</span>
              </button>
              <span className="text-emerald-400 font-bold">{selectedYear}</span>
            </div>
          </div>
        )}
      </div>

      {/* Floating Top Right Controls Bar */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
        {/* Dropdown: Basemap Selection */}
        <div className="relative">
          <select
            value={basemapStyle}
            onChange={(e) => setBasemapStyle(e.target.value as any)}
            className="bg-slate-900/95 border border-slate-800 text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-emerald-500 font-medium shadow-xl backdrop-blur-md cursor-pointer appearance-none pr-8"
          >
            <option value="google_hybrid">🛰️ Basemap: Google Satellite (Hybrid)</option>
            <option value="google_satellite">🛰️ Basemap: Google Satellite (Pure)</option>
            <option value="osm">🗺️ Basemap: OpenStreetMap (OSM)</option>
            <option value="dark">🌃 Basemap: CartoDB Dark</option>
            <option value="esri_satellite">🌍 Basemap: Esri World Satellite</option>
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5 pointer-events-none" />
        </div>

        {/* Dropdown: Kelompokkan berdasar... */}
        <div className="relative">
          <select
            value={groupingMode}
            onChange={(e) => setGroupingMode(e.target.value)}
            className="bg-slate-900/95 border border-slate-800 text-slate-200 text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-emerald-500 font-medium shadow-xl backdrop-blur-md cursor-pointer appearance-none pr-8"
          >
            <option value="Wilayah / Kabupaten">Kelompokkan: Wilayah</option>
            <option value="Provinsi">Kelompokkan: Provinsi</option>
            <option value="DAS (Daerah Aliran Sungai)">Kelompokkan: DAS</option>
            <option value="Kelas Risk">Kelompokkan: Kelas Risk</option>
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2.5 pointer-events-none" />
        </div>

        {/* Quick Toolbar Icons */}
        <div className="bg-slate-900/95 border border-slate-800 rounded-lg p-1 flex items-center gap-1 shadow-xl backdrop-blur-md">
          <button
            onClick={onResetView}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors flex items-center gap-1 text-xs px-2"
            title="Reset Peta ke Tampilan Wilayah Jawa Barat"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline font-mono text-[11px]">Reset View</span>
          </button>
        </div>
      </div>

      {/* Loading Overlay */}
      {isMapLoading && (
        <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm z-30 flex items-center justify-center">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-2xl flex items-center gap-3">
            <span className="w-5 h-5 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin"></span>
            <div className="text-xs">
              <div className="font-bold text-slate-100">Memotong Raster GEE (.clip)...</div>
              <div className="text-[10px] text-slate-400 font-mono">Menghitung reduceRegion zonal statistics</div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Floating Time Slider & Map Controls Bar */}
      <div className="absolute bottom-4 left-4 right-4 z-20 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 pointer-events-none">
        {/* Timeline Slider with Play/Pause Timelapse */}
        {isTimelineVisible ? (
          <div className="bg-slate-900/95 border border-slate-800 rounded-xl px-3.5 py-2 shadow-2xl flex items-center gap-2.5 backdrop-blur-md pointer-events-auto max-w-2xl w-full">
            {/* Play / Pause Timelapse Button */}
            <button
              onClick={() => setIsPlayingTimelapse(!isPlayingTimelapse)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 ${
                isPlayingTimelapse
                  ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 animate-pulse'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg shadow-emerald-950/40'
              }`}
              title={isPlayingTimelapse ? 'Jeda Simulasi Timelapse' : 'Putar Simulasi Timelapse Kebencanaan'}
            >
              {isPlayingTimelapse ? (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span className="font-mono text-[11px]">Jeda</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span className="font-mono text-[11px]">Timelapse</span>
                </>
              )}
            </button>

            {/* Selected Year Badge */}
            <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 px-2 py-1 rounded-lg shrink-0 font-mono">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-xs font-black text-emerald-400">{selectedYear}</span>
            </div>

            {/* Compact & Proportional Slider Container */}
            <div className="flex-1 flex flex-col justify-center px-1 min-w-[120px] sm:min-w-[180px]">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold text-slate-400 font-mono shrink-0">2018</span>
                <input
                  type="range"
                  min="2018"
                  max="2025"
                  step="1"
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                  className="custom-slider w-full cursor-pointer"
                />
                <span className="text-[10px] font-bold text-slate-400 font-mono shrink-0">2025</span>
              </div>

              {/* Clickable Tick Dots / Quick Year Selectors */}
              <div className="flex justify-between items-center px-[18px] mt-0.5 text-[8px] font-mono text-slate-500">
                {[2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025].map((yr) => (
                  <button
                    key={yr}
                    onClick={() => setSelectedYear(yr)}
                    className={`transition-all hover:text-emerald-400 font-bold ${
                      selectedYear === yr ? 'text-emerald-400 scale-125' : 'text-slate-500'
                    }`}
                    title={`Pilih tahun ${yr}`}
                  >
                    •
                  </button>
                ))}
              </div>
            </div>

            {/* Toggle Incident Pins */}
            <button
              onClick={onToggleIncidents}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 font-mono shrink-0 transition-colors ${
                showIncidents && !showAllIncidentsMode
                  ? 'bg-rose-950/80 border-rose-800 text-rose-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
              title="Tampilkan / Sembunyikan Titik Kejadian Bencana Tahun Aktif"
            >
              <MapPin className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[10px]">Titik ({selectedYear})</span>
            </button>


            {/* Button: Kejadian Bencana Secara Keseluruhan */}
            <button
              onClick={() => {
                if (onToggleAllIncidentsMode) onToggleAllIncidentsMode();
              }}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 font-mono shrink-0 transition-all ${
                showAllIncidentsMode
                  ? 'bg-rose-950/90 border-rose-600 text-rose-300 shadow-md shadow-rose-950/50'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
              title="Tampilkan / Sembunyikan Semua Kejadian Bencana (2018-2025)"
            >
              <Flame className={`w-3.5 h-3.5 ${showAllIncidentsMode ? 'text-amber-400 animate-pulse' : 'text-rose-400'}`} />
              <span className={`px-1 py-0.2 rounded text-[9px] font-mono font-bold ${
                showAllIncidentsMode ? 'bg-rose-500 text-white' : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}>
                {DISASTER_INCIDENTS.length}
              </span>
            </button>

            {/* Detail Rekap Modal Button */}
            {onOpenAllIncidentsModal && (
              <button
                onClick={onOpenAllIncidentsModal}
                className="p-1.5 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1 text-[10px] font-mono shrink-0"
                title="Buka Rekapitulasi & Tabel Kejadian Bencana"
              >
                <ListFilter className="w-3.5 h-3.5 text-amber-400" />
              </button>
            )}

            {/* Hide Timeline Toggle Button */}
            <button
              onClick={() => setIsTimelineVisible(false)}
              className="p-1.5 rounded-lg border border-slate-800 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors shrink-0"
              title="Sembunyikan Panel Timelapse & Timeline"
            >
              <EyeOff className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>
        ) : (
          /* Unhide Timeline Pill Button */
          <button
            onClick={() => setIsTimelineVisible(true)}
            className="bg-slate-900/95 border border-slate-800 rounded-xl px-3 py-2 shadow-2xl flex items-center gap-2 text-xs font-mono text-emerald-400 hover:text-emerald-300 hover:bg-slate-800 transition-all backdrop-blur-md pointer-events-auto"
            title="Tampilkan Panel Timelapse & Timeline"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span className="text-[11px] font-bold">Timelapse &amp; Timeline ({selectedYear})</span>
            <Eye className="w-3.5 h-3.5 text-slate-400 ml-1" />
          </button>
        )}

        {/* Scale & Coordinates Footer Bar */}
        {isScaleVisible ? (
          <div className="bg-slate-900/95 border border-slate-800 rounded-xl px-3.5 py-2.5 shadow-2xl flex items-center gap-3 text-xs font-mono backdrop-blur-md pointer-events-auto">
            {/* Scale bar indicator */}
            <div className="flex items-center gap-2 pr-3 border-r border-slate-800">
              <span className="text-slate-400 text-[10px]">Scale:</span>
              <div className="w-12 h-1 bg-slate-700 relative border-x border-slate-400">
                <span className="absolute -top-3 left-0 text-[9px] text-slate-300">0</span>
                <span className="absolute -top-3 right-0 text-[9px] text-slate-300">50km</span>
              </div>
            </div>

            {/* Real-time Lat / Lon */}
            <div className="flex items-center gap-2 text-[10px]">
              <Compass className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-slate-400">lat:</span>
              <span className="text-slate-200">{mouseCoords.lat}</span>
              <span className="text-slate-400">lon:</span>
              <span className="text-slate-200">{mouseCoords.lng}</span>
            </div>

            {/* Hide Scale Toggle Button */}
            <button
              onClick={() => setIsScaleVisible(false)}
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors ml-1"
              title="Sembunyikan Panel Skala & GPS"
            >
              <EyeOff className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          /* Unhide Scale Pill Button */
          <button
            onClick={() => setIsScaleVisible(true)}
            className="bg-slate-900/95 border border-slate-800 rounded-xl px-3 py-2 shadow-2xl flex items-center gap-2 text-xs font-mono text-slate-300 hover:text-white hover:bg-slate-800 transition-all backdrop-blur-md pointer-events-auto"
            title="Tampilkan Skala & GPS"
          >
            <Compass className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[11px]">Skala &amp; GPS</span>
            <Eye className="w-3.5 h-3.5 text-slate-400 ml-1" />
          </button>
        )}
      </div>
    </div>
  );
};
