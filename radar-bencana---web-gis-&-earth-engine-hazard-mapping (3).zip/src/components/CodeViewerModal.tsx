import React, { useState } from 'react';
import { X, Copy, Check, Download, FileCode, Server, Map, Sparkles, Terminal } from 'lucide-react';
import { PythonCodeTab } from '../types';

interface CodeViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CodeViewerModal: React.FC<CodeViewerModalProps> = ({ isOpen, onClose }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<number>(0);

  if (!isOpen) return null;

  const codeTabs: PythonCodeTab[] = [
    {
      filename: 'gee_service.py',
      language: 'python',
      description: 'Module Python GEE untuk inisialisasi Service Account, clipping raster .tif hazard, dan kalkulasi zonal statistics dengan reduceRegion.',
      code: `"""
Google Earth Engine (GEE) Service Module for Disaster Hazard Mapping
Handles GEE initialization, Image asset loading, geometry clipping, and zonal statistics via reduceRegion.
"""

import os
import json
import logging
from typing import Optional, Dict, Any

try:
    import ee
    GEE_AVAILABLE = True
except ImportError:
    GEE_AVAILABLE = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("GEEService")


class GEEDisasterService:
    def __init__(self, service_account: Optional[str] = None, key_file: Optional[str] = None):
        self.initialized = False
        self._init_gee(service_account, key_file)

    def _init_gee(self, service_account: Optional[str], key_file: Optional[str]):
        """Initialize Google Earth Engine API using Service Account or default credentials."""
        if not GEE_AVAILABLE:
            logger.warning("Google Earth Engine ('ee') Python library is not installed.")
            return

        try:
            if service_account and key_file and os.path.exists(key_file):
                logger.info(f"Initializing GEE with Service Account: {service_account}")
                credentials = ee.ServiceAccountCredentials(service_account, key_file)
                ee.Initialize(credentials)
            else:
                logger.info("Initializing GEE with default application credentials / project...")
                ee.Initialize(project=os.getenv("GEE_PROJECT_ID", "ee-disaster-hazard-mapping"))
            self.initialized = True
            logger.info("GEE successfully initialized.")
        except Exception as e:
            logger.error(f"Failed to initialize GEE: {str(e)}")
            self.initialized = False

    def get_hazard_image(self, hazard_type: str = "flood") -> Any:
        """
        Loads a hazard raster dataset from GEE Assets or standard datasets.
        In production, replace asset IDs with your custom .tif Asset paths.
        """
        if hazard_type == "flood":
            water = ee.Image("JRC/GSW1_4/GlobalSurfaceWater").select("occurrence")
            dem = ee.Image("USGS/SRTMGL1_003")
            hazard = ee.Image(0) \\
                .where(water.gt(20).And(dem.lt(100)), 1) \\
                .where(water.gt(50).And(dem.lt(50)), 2) \\
                .where(water.gt(80).And(dem.lt(20)), 3)
            return hazard.rename("hazard_class")
        else:
            asset_path = f"projects/gee-disaster-mapping/assets/{hazard_type}_raster"
            return ee.Image(asset_path).select(0).rename("hazard_class")

    def get_map_tile_url(self, hazard_type: str, geometry_geojson: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Clips the hazard image to administrative geometry (if provided) and gets map tile URL (MapID).
        """
        image = self.get_hazard_image(hazard_type)

        if geometry_geojson:
            ee_geometry = ee.Geometry(geometry_geojson)
            image = image.clip(ee_geometry)

        vis_params = {
            "min": 0,
            "max": 3,
            "palette": ["93c5fd", "3b82f6", "1d4ed8", "1e1b4b"]
        }

        map_id_dict = image.getMapId(vis_params)

        return {
            "mapId": map_id_dict["mapid"],
            "tileUrlPattern": map_id_dict["tile_fetcher"].url_format,
            "hazardType": hazard_type,
            "isClipped": geometry_geojson is not None
        }

    def compute_zonal_statistics(self, hazard_type: str, geometry_geojson: Dict[str, Any], scale: int = 30) -> Dict[str, Any]:
        """
        Uses reduceRegion to compute total area in hectares per hazard class inside the clicked polygon.
        """
        image = self.get_hazard_image(hazard_type)
        ee_geometry = ee.Geometry(geometry_geojson)

        pixel_area = ee.Image.pixelArea()
        hazard_with_area = image.addBands(pixel_area)

        stats = hazard_with_area.reduceRegion(
            reducer=ee.Reducer.sum().group(
                groupField=0,
                groupName="hazard_class"
            ),
            geometry=ee_geometry,
            scale=scale,
            maxPixels=1e9
        )

        raw_groups = stats.get("groups").getInfo()
        hectares_by_class = {0: 0.0, 1: 0.0, 2: 0.0, 3: 0.0}
        total_ha = 0.0

        for group in raw_groups:
            cls_id = int(group.get("hazard_class", 0))
            area_m2 = float(group.get("sum", 0.0))
            area_ha = round(area_m2 / 10000.0, 2)
            hectares_by_class[cls_id] = area_ha
            total_ha += area_ha

        return {
            "totalAreaHa": round(total_ha, 2),
            "lowRiskHa": hectares_by_class.get(0, 0.0),
            "mediumRiskHa": hectares_by_class.get(1, 0.0),
            "highRiskHa": hectares_by_class.get(2, 0.0) + hectares_by_class.get(3, 0.0),
            "scaleMeters": scale
        }
`
    },
    {
      filename: 'main.py (FastAPI)',
      language: 'python',
      description: 'Server FastAPI dengan endpoint RESTful /get-map-layer dan /get-statistics.',
      code: `"""
FastAPI Backend Server for Google Earth Engine Disaster Hazard Web GIS
Provides endpoints for GEE Map Tile rendering (clipped) and Zonal Statistics calculation.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any

from gee_service import GEEDisasterService

app = FastAPI(title="GEE Disaster Hazard Web GIS API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

gee_service = GEEDisasterService()


class MapLayerRequest(BaseModel):
    hazardType: str = "flood"
    geometry: Optional[Dict[str, Any]] = None


class ZonalStatsRequest(BaseModel):
    districtId: str
    hazardType: str = "flood"
    geometry: Dict[str, Any]
    scaleMeters: Optional[int] = 30


@app.post("/get-map-layer")
def get_map_layer(payload: MapLayerRequest):
    try:
        result = gee_service.get_map_tile_url(
            hazard_type=payload.hazardType,
            geometry_geojson=payload.geometry
        )
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/get-statistics")
def get_statistics(payload: ZonalStatsRequest):
    try:
        stats = gee_service.compute_zonal_statistics(
            hazard_type=payload.hazardType,
            geometry_geojson=payload.geometry,
            scale=payload.scaleMeters or 30
        )
        return {"status": "success", "districtId": payload.districtId, "data": stats}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
`
    },
    {
      filename: 'MapContainer.tsx (React + Leaflet)',
      language: 'typescript',
      description: 'Komponen React Web GIS Leaflet untuk menangani event click polygon, highlighting, dan dynamic overlay clipping.',
      code: `// React + Leaflet Interactive Clipping Component Snippet
import React, { useEffect, useRef } from 'react';
import L from 'leaflet';

export const MapComponent = ({ adminGeoJson, onSelectDistrict }) => {
  const mapRef = useRef(null);

  useEffect(() => {
    const map = L.map(mapRef.current).setView([-6.85, 107.50], 9);
    
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png').addTo(map);

    L.geoJSON(adminGeoJson, {
      onEachFeature: (feature, layer) => {
        layer.on('click', () => {
          onSelectDistrict(feature);
          // Highlight & Fetch FastAPI GEE clipped tiles
        });
      }
    }).addTo(map);
  }, []);

  return <div ref={mapRef} style={{ width: '100%', height: '100%' }} />;
};
`
    }
  ];

  const handleCopyCode = (index: number, code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleDownloadFile = (filename: string, code: string) => {
    const element = document.createElement('a');
    const file = new Blob([code], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-950 border border-blue-800 text-blue-400">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-base">Google Earth Engine & FastAPI Source Code</h3>
              <p className="text-xs text-slate-400 font-mono">Step 1 (Python FastAPI + GEE) & Step 2 (React + Leaflet GIS)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex items-center border-b border-slate-800 bg-slate-950/40 px-4 pt-2 gap-2 overflow-x-auto">
          {codeTabs.map((tab, idx) => (
            <button
              key={idx}
              onClick={() => setActiveTab(idx)}
              className={`px-4 py-2 text-xs font-semibold font-mono rounded-t-lg transition-all flex items-center gap-2 border-t border-x ${
                activeTab === idx
                  ? 'bg-slate-900 text-emerald-400 border-slate-800 border-b-transparent shadow-lg'
                  : 'bg-slate-950/60 text-slate-400 hover:text-slate-200 border-transparent'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>{tab.filename}</span>
            </button>
          ))}
        </div>

        {/* Code Content */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-950 font-mono text-xs">
          <div className="mb-4 p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between text-slate-300">
            <span className="text-xs text-slate-400">{codeTabs[activeTab].description}</span>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => handleCopyCode(activeTab, codeTabs[activeTab].code)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs flex items-center gap-1.5 transition-colors border border-slate-700"
              >
                {copiedIndex === activeTab ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Disalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Salin Kode</span>
                  </>
                )}
              </button>
              <button
                onClick={() => handleDownloadFile(codeTabs[activeTab].filename, codeTabs[activeTab].code)}
                className="px-3 py-1.5 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 rounded text-xs flex items-center gap-1.5 transition-colors border border-emerald-800"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Unduh File</span>
              </button>
            </div>
          </div>

          <pre className="p-4 bg-slate-900/90 rounded-xl border border-slate-800/80 text-emerald-300/90 overflow-x-auto leading-relaxed selection:bg-emerald-900 selection:text-emerald-100">
            <code>{codeTabs[activeTab].code}</code>
          </pre>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
          >
            Tutup Code Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
