import React, { useState } from 'react';
import { 
  Search, 
  MapPin, 
  Code2, 
  Globe, 
  Layers, 
  ChevronDown,
  Upload,
  RotateCcw,
  ShieldCheck
} from 'lucide-react';
import { AdminFeature } from '../types';

interface HeaderProps {
  districts: AdminFeature[];
  selectedDistrict: AdminFeature | null;
  onSelectDistrict: (district: AdminFeature | null) => void;
  onOpenCodeViewer: () => void;
  onOpenGeometryModal: () => void;
  onNavigateToLogin: () => void;
  onResetView: () => void;
  lang: 'ID' | 'EN';
  onToggleLang: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  districts,
  selectedDistrict,
  onSelectDistrict,
  onOpenCodeViewer,
  onOpenGeometryModal,
  onNavigateToLogin,
  onResetView,
  lang,
  onToggleLang,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const filteredDistricts = districts.filter((d) =>
    d.properties.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.properties.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <header className="bg-slate-950 border-b border-slate-800 text-slate-100 h-14 px-4 flex items-center justify-between z-30 shrink-0">
      {/* Brand & Logo */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 cursor-pointer hover:opacity-90 transition-opacity" onClick={onResetView}>
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-emerald-600 via-teal-500 to-amber-400 p-[2px] flex items-center justify-center shadow-lg shadow-emerald-950/50">
            <div className="w-full h-full bg-slate-950 rounded-[6px] flex items-center justify-center">
              <Layers className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5 leading-none font-sans">
              <span className="text-emerald-400 font-black text-base tracking-widest uppercase">RADAR</span>
              <span className="text-amber-400 font-bold text-[11px] tracking-wider uppercase bg-amber-950/60 border border-amber-500/30 px-1.5 py-0.5 rounded">BENCANA</span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono tracking-tight mt-0.5 leading-tight" title="Rekapitulasi Analisis Dampak Area dan Risiko Bencana">
              Rekapitulasi Analisis Dampak Area &amp; Risiko
            </p>
          </div>
        </div>

        {/* Breadcrumb path */}
        <div className="hidden lg:flex items-center gap-2 text-xs text-slate-400 bg-slate-900 px-3 py-1 rounded-full border border-slate-800/80 ml-4 font-mono">
          <span className="hover:text-slate-200 cursor-pointer" onClick={onResetView}>Indonesia</span>
          <span>/</span>
          <span className="hover:text-slate-200 cursor-pointer" onClick={onResetView}>Jawa</span>
          <span>/</span>
          <span className="text-emerald-400 font-semibold">
            {selectedDistrict ? selectedDistrict.properties.name : 'Jawa Barat (Full Region)'}
          </span>
        </div>
      </div>

      {/* Middle Search & Custom Geometry button */}
      <div className="flex items-center gap-2 max-w-md w-full px-4">
        <div className="relative flex-1">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 absolute left-3 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder={lang === 'ID' ? 'Pilih satu atau lebih wilayah...' : 'Select region or district...'}
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsSearchOpen(true);
              }}
              onFocus={() => setIsSearchOpen(true)}
              className="w-full bg-slate-900 border border-slate-700/80 rounded-lg pl-9 pr-8 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setIsSearchOpen(false);
                }}
                className="absolute right-2.5 text-slate-400 hover:text-slate-200 text-xs"
              >
                ×
              </button>
            )}
          </div>

          {/* Search Dropdown */}
          {isSearchOpen && searchQuery && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-slate-900 border border-slate-800 rounded-lg shadow-2xl overflow-hidden z-50 max-h-60 overflow-y-auto">
              {filteredDistricts.length > 0 ? (
                filteredDistricts.map((district) => (
                  <button
                    key={district.id}
                    onClick={() => {
                      onSelectDistrict(district);
                      setSearchQuery('');
                      setIsSearchOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs text-slate-200 hover:bg-slate-800 flex items-center justify-between border-b border-slate-800/50 last:border-0"
                  >
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <div>
                        <div className="font-medium text-slate-100">{district.properties.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{district.properties.province}</div>
                      </div>
                    </div>
                    <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                      {district.properties.total_area_ha.toLocaleString()} ha
                    </span>
                  </button>
                ))
              ) : (
                <div className="px-3 py-3 text-xs text-slate-400 text-center">
                  Wilayah tidak ditemukan
                </div>
              )}
            </div>
          )}
        </div>

        {/* Custom Geometry button */}
        <button
          onClick={onOpenGeometryModal}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-medium border border-slate-700/80 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <Upload className="w-3.5 h-3.5 text-emerald-400" />
          <span>{lang === 'ID' ? 'Geometri saya' : 'My Geometry'}</span>
        </button>
      </div>

      {/* Right Action buttons */}
      <div className="flex items-center gap-2">
        {selectedDistrict && (
          <button
            onClick={onResetView}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-950/80 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-700/60 rounded-lg text-xs font-medium transition-colors"
            title="Clear clipping & return to full regional view"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Clip</span>
          </button>
        )}

        {/* Super Admin Routing Button */}
        <button
          onClick={onNavigateToLogin}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-950 via-slate-900 to-amber-950/90 hover:from-emerald-900 hover:to-amber-900 text-emerald-300 border border-emerald-700/80 rounded-lg text-xs font-semibold shadow-md shadow-emerald-950/40 transition-all"
          title="Login Portal Super Admin"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Super Admin</span>
        </button>

        {/* Python FastAPI + GEE Code Inspector Button */}
        <button
          onClick={onOpenCodeViewer}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold rounded-lg shadow-md shadow-blue-950/50 transition-all border border-blue-400/30"
          title="Inspect Python FastAPI & GEE reduceRegion backend code"
        >
          <Code2 className="w-3.5 h-3.5 text-blue-100" />
          <span className="hidden md:inline">GEE Backend Code</span>
          <span className="md:hidden">Code</span>
        </button>

        {/* Language switch */}
        <button
          onClick={onToggleLang}
          className="p-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 text-xs font-mono flex items-center gap-1"
          title="Switch Language"
        >
          <Globe className="w-3.5 h-3.5 text-slate-400" />
          <span>{lang}</span>
        </button>
      </div>
    </header>
  );
};
