import React, { useState } from 'react';
import { X, Copy, Check, Terminal, FileCode2, ExternalLink } from 'lucide-react';

interface PythonCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'id' | 'en';
}

export const PythonCodeModal: React.FC<PythonCodeModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  const [copiedTab, setCopiedTab] = useState<string | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'fastapi' | 'gee' | 'requirements'>('fastapi');

  if (!isOpen) return null;

  const fastapiCode = `"""
FastAPI + Google Earth Engine (GEE) Disaster Hazard Mapping Backend
Step 1: Backend Development
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any
import ee
import os

app = FastAPI(
    title="GEE Web GIS Disaster Hazard Mapping API",
    description="Backend service for raster visualization, polygon clipping, and reduceRegion zonal statistics.",
    version="1.0.0"
)

# 1. Initialize Google Earth Engine Service Account
try:
    # Use Service Account JSON or High-Volume Cloud Project Credentials
    service_account = os.getenv("GEE_SERVICE_ACCOUNT")
    key_file = os.getenv("GEE_KEY_FILE")
    
    if service_account and key_file and os.path.exists(key_file):
        credentials = ee.ServiceAccountCredentials(service_account, key_file)
        ee.Initialize(credentials)
    else:
        ee.Initialize(project=os.getenv("GEE_PROJECT_ID", "ee-disaster-hazard-mapping"))
    print("Google Earth Engine initialized successfully.")
except Exception as e:
    print(f"GEE Initialization Warning: {str(e)}")


class MapLayerRequest(BaseModel):
    hazard_type: str = "flood" # 'flood', 'landslide', 'wildfire'
    geometry: Optional[Dict[str, Any]] = None # GeoJSON polygon from clicked administrative area

class StatisticsRequest(BaseModel):
    hazard_type: str = "flood"
    geometry: Dict[str, Any] # GeoJSON polygon
    scale_meters: int = 30


@app.post("/get-map-layer")
def get_map_layer(req: MapLayerRequest):
    """
    Loads hazard raster image (e.g., .tif asset in GEE),
    clips to administrative boundary if provided, and returns map tile URL (MapID).
    """
    try:
        # Load Hazard Image Asset (replace with your custom .tif asset ID)
        if req.hazard_type == "flood":
            # Example: 100-Year Flood Inundation Depth Model
            image = ee.Image("JRC/GSW1_4/GlobalSurfaceWater").select("occurrence")
            dem = ee.Image("USGS/SRTMGL1_003")
            # Classify into 4 hazard levels (0=Low, 1=Medium, 2=High, 3=Extreme)
            hazard_image = ee.Image(0)\\
                .where(image.gt(20).And(dem.lt(100)), 1)\\
                .where(image.gt(50).And(dem.lt(50)), 2)\\
                .where(image.gt(80).And(dem.lt(20)), 3)
        else:
            # Custom Asset Fallback
            asset_path = f"projects/gee-disaster-mapping/assets/{req.hazard_type}_raster"
            hazard_image = ee.Image(asset_path).select(0)

        # Dynamic Clipping to Administrative Polygon
        if req.geometry:
            ee_geom = ee.Geometry(req.geometry)
            hazard_image = hazard_image.clip(ee_geom)

        # Apply Color Palette for Hazard Levels
        vis_params = {
            "min": 0,
            "max": 3,
            "palette": ["93c5fd", "3b82f6", "1d4ed8", "1e1b4b"] # Low to Extreme Blue
        }

        map_id_dict = hazard_image.getMapId(vis_params)

        return {
            "success": True,
            "mapId": map_id_dict["mapid"],
            "tileUrlPattern": map_id_dict["tile_fetcher"].url_format,
            "isClipped": req.geometry is not None
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/get-statistics")
def get_statistics(req: StatisticsRequest):
    """
    Uses reduceRegion to calculate total area in hectares per hazard class 
    specifically for the clicked administrative geometry.
    """
    try:
        # Load hazard image
        image = ee.Image("JRC/GSW1_4/GlobalSurfaceWater").select("occurrence")
        dem = ee.Image("USGS/SRTMGL1_003")
        hazard_class = ee.Image(0)\\
            .where(image.gt(20).And(dem.lt(100)), 1)\\
            .where(image.gt(50).And(dem.lt(50)), 2)\\
            .where(image.gt(80).And(dem.lt(20)), 3)

        ee_geom = ee.Geometry(req.geometry)
        pixel_area = ee.Image.pixelArea() # Area per pixel in square meters

        hazard_with_area = hazard_class.addBands(pixel_area)

        # Grouped reduceRegion sum
        stats = hazard_with_area.reduceRegion(
            reducer=ee.Reducer.sum().group(groupField=0, groupName="class_id"),
            geometry=ee_geom,
            scale=req.scale_meters,
            maxPixels=1e9
        )

        raw_groups = stats.get("groups").getInfo()
        
        total_ha = 0.0
        class_areas = {}

        for group in raw_groups:
            cls_id = int(group.get("class_id", 0))
            area_m2 = float(group.get("sum", 0.0))
            area_ha = round(area_m2 / 10000.0, 2)
            class_areas[cls_id] = area_ha
            total_ha += area_ha

        return {
            "success": True,
            "totalAreaHa": total_ha,
            "lowRiskHa": class_areas.get(0, 0.0),
            "mediumRiskHa": class_areas.get(1, 0.0),
            "highRiskHa": class_areas.get(2, 0.0) + class_areas.get(3, 0.0),
            "rawClassBreakdown": class_areas
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
`;

  const requirementsTxt = `fastapi==0.110.0
uvicorn==0.28.0
earthengine-api==0.1.395
pydantic==2.6.4
python-dotenv==1.0.1
`;

  const copyToClipboard = (text: string, tabName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(tabName);
    setTimeout(() => setCopiedTab(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700/80 rounded-xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden text-slate-200">
        {/* Modal Header */}
        <div className="px-5 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">
                Python FastAPI + Google Earth Engine (GEE) Code
              </h3>
              <p className="text-[11px] text-slate-400">
                {lang === 'id' ? 'Kode backend siap pakai untuk clipping & reduceRegion zonal statistics.' : 'Ready-to-use backend code for clipping & reduceRegion zonal statistics.'}
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Code Tabs */}
        <div className="flex items-center justify-between px-5 py-2 bg-slate-950/80 border-b border-slate-800 text-xs font-semibold">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveCodeTab('fastapi')}
              className={`px-3 py-1.5 rounded-md flex items-center space-x-1.5 transition ${
                activeCodeTab === 'fastapi' ? 'bg-emerald-950 text-emerald-300 border border-emerald-600/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode2 className="w-4 h-4 text-emerald-400" />
              <span>main.py (FastAPI + GEE)</span>
            </button>

            <button
              onClick={() => setActiveCodeTab('requirements')}
              className={`px-3 py-1.5 rounded-md flex items-center space-x-1.5 transition ${
                activeCodeTab === 'requirements' ? 'bg-emerald-950 text-emerald-300 border border-emerald-600/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-4 h-4 text-amber-400" />
              <span>requirements.txt</span>
            </button>
          </div>

          <button
            onClick={() => copyToClipboard(activeCodeTab === 'fastapi' ? fastapiCode : requirementsTxt, activeCodeTab)}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition border border-slate-700"
          >
            {copiedTab === activeCodeTab ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>{lang === 'id' ? 'Tersalin!' : 'Copied!'}</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-400" />
                <span>{lang === 'id' ? 'Salin Kode' : 'Copy Code'}</span>
              </>
            )}
          </button>
        </div>

        {/* Code Block */}
        <div className="flex-1 overflow-y-auto p-5 bg-slate-950 font-mono text-xs text-slate-300">
          <pre className="whitespace-pre-wrap leading-relaxed">
            {activeCodeTab === 'fastapi' ? fastapiCode : requirementsTxt}
          </pre>
        </div>
      </div>
    </div>
  );
};
