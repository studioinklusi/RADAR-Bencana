import express, { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import fs from 'fs';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '20mb' }));

// Ensure upload directory exists
const UPLOAD_DIR = path.resolve(process.cwd(), 'public', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}
const LAYERS_INDEX_PATH = path.join(UPLOAD_DIR, 'layers_index.json');

function getLayersIndex(): any[] {
  if (fs.existsSync(LAYERS_INDEX_PATH)) {
    try {
      const data = fs.readFileSync(LAYERS_INDEX_PATH, 'utf-8');
      return JSON.parse(data);
    } catch {
      return [];
    }
  }
  return [];
}

function saveLayersIndex(layers: any[]) {
  fs.writeFileSync(LAYERS_INDEX_PATH, JSON.stringify(layers, null, 2), 'utf-8');
}

// Lazy initialization for Gemini API
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is not set.');
    }
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

// Map layer endpoint (GEE or Tile simulation)
app.post('/api/get-map-layer', (req: Request, res: Response) => {
  try {
    const { hazardType = 'flood', geometry, districtId } = req.body;
    const isClipped = !!geometry && !!districtId;

    res.json({
      success: true,
      layerId: hazardType,
      mapId: `gee_map_${hazardType}_${districtId || 'regional'}_${Date.now()}`,
      isClipped,
      clippedDistrictId: districtId || null,
      geeAssetUsed: `projects/gee-disaster-mapping/assets/${hazardType}_jawa_barat_2024`,
      palette: ['#10b981', '#f59e0b', '#ef4444', '#7f1d1d'],
      timestamp: new Date().toISOString()
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Zonal Statistics Endpoint (reduceRegion simulator)
app.post('/api/get-statistics', (req: Request, res: Response) => {
  try {
    const { districtId, districtName, hazardType = 'flood', year = 2024 } = req.body;

    if (!districtId) {
      return res.json({
        districtId: 'JAWA-BARAT-PROV',
        districtName: 'Jawa Barat (Keseluruhan)',
        provinceName: 'Jawa Barat',
        totalAreaHa: 3701261,
        year: year,
        chartData: [
          { name: 'Pertanian', ha: 1540436, percentage: 41.6, color: '#ec4899', classId: 1 },
          { name: 'Hutan', ha: 808671, percentage: 21.8, color: '#10b981', classId: 2 },
          { name: 'Tumbuhan Non-Hutan', ha: 688381, percentage: 18.6, color: '#eab308', classId: 3 },
          { name: 'Non Vegetasi', ha: 563283, percentage: 15.2, color: '#ef4444', classId: 4 },
          { name: 'Tubuh Air', ha: 103578, percentage: 2.8, color: '#3b82f6', classId: 5 }
        ],
        summary: {
          highRiskHa: 563283,
          mediumRiskHa: 688381,
          lowRiskHa: 2349107,
          riskCategory: 'High'
        }
      });
    }

    const seed = districtId.split('').reduce((acc: number, char: string) => acc + char.charCodeAt(0), 0);
    const totalHa = 80000 + (seed % 150000);

    const p1 = 35 + (seed % 20); // Pertanian
    const p2 = 15 + ((seed * 3) % 20); // Hutan
    const p3 = 15 + ((seed * 7) % 15); // Non Hutan
    const p4 = 10 + ((seed * 11) % 20); // Non Vegetasi
    const p5 = Number((100 - (p1 + p2 + p3 + p4)).toFixed(1)); // Tubuh Air

    const ha1 = Math.round((totalHa * p1) / 100);
    const ha2 = Math.round((totalHa * p2) / 100);
    const ha3 = Math.round((totalHa * p3) / 100);
    const ha4 = Math.round((totalHa * p4) / 100);
    const ha5 = Math.round(totalHa - (ha1 + ha2 + ha3 + ha4));

    res.json({
      districtId,
      districtName: districtName || districtId,
      provinceName: 'Jawa Barat',
      totalAreaHa: totalHa,
      year: year,
      chartData: [
        { name: 'Pertanian', ha: ha1, percentage: p1, color: '#ec4899', classId: 1 },
        { name: 'Hutan', ha: ha2, percentage: p2, color: '#10b981', classId: 2 },
        { name: 'Tumbuhan Non-Hutan', ha: ha3, percentage: p3, color: '#eab308', classId: 3 },
        { name: 'Non Vegetasi', ha: ha4, percentage: p4, color: '#ef4444', classId: 4 },
        { name: 'Tubuh Air', ha: ha5, percentage: Math.max(0.5, p5), color: '#3b82f6', classId: 5 }
      ],
      summary: {
        highRiskHa: ha4,
        mediumRiskHa: ha3,
        lowRiskHa: ha1 + ha2 + ha5,
        riskCategory: ha4 > ha2 ? 'Kritis / Tinggi' : 'Sedang'
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Gemini AI Risk & Vulnerability Assessment
app.post('/api/generate-ai-report', async (req: Request, res: Response) => {
  try {
    const { districtName, provinceName = 'Jawa Barat', stats, hazardType = 'flood' } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.json({
        success: true,
        report: {
          executiveSummary: `Wilayah ${districtName} (${provinceName}) memiliki risiko kerentanan ${hazardType.toUpperCase()} dengan kategori ${stats?.summary?.riskCategory || 'Tinggi'}. Sebagian besar area berupa lahan pertanian dan kawasan terbangun non-vegetasi.`,
          keyVulnerabilities: [
            'Tinggi curah hujan harian & kemiringan lereng di area hulu',
            'Konversi lahan hutan primer menjadi kawasan pemukiman',
            'Penyempitan dan pendangkalan alur sungai utama'
          ],
          actionableMitigations: [
            'Restorasi kawasan resapan air dan vegetasi hutan di hulu',
            'Pemasangan Sensor Peringatan Dini (EWS) Banjir & Longsor',
            'Penguatan tanggul sungai dan pengerukan sedimen berkala'
          ]
        }
      });
    }

    const ai = getGeminiClient();
    const prompt = `Anda adalah Spesialis SIG (GIS Specialist) dan Ahli Penanggulangan Bencana Google Earth Engine.
Berikan analisis teknis dan rekomendasi aksi kebencanaan untuk:
- Wilayah: ${districtName}, ${provinceName}
- Jenis Ancaman: ${hazardType}
- Statistik Tutupan Area: ${JSON.stringify(stats)}

Format jawaban JSON:
{
  "executiveSummary": "ringkasan 2-3 kalimat kondisi risiko wilayah",
  "keyVulnerabilities": ["faktor 1", "faktor 2", "faktor 3"],
  "actionableMitigations": ["langkah 1", "langkah 2", "langkah 3"]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: { responseMimeType: 'application/json' }
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json({ success: true, report: parsed });
  } catch (err: any) {
    console.error('Gemini error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin Upload Layer Endpoint
app.post('/api/upload-layer', (req: Request, res: Response) => {
  try {
    const { filename, layerName, description, fileType, fileContent, category, spatialAttributes, fieldMapping } = req.body;

    if (!filename || !fileContent) {
      return res.status(400).json({ success: false, error: 'Nama file dan isi data tidak boleh kosong.' });
    }

    const safeFilename = `${Date.now()}_${filename.replace(/[^a-zA-Z0-0_.-]/g, '_')}`;
    const filePath = path.join(UPLOAD_DIR, safeFilename);

    let savedContent = fileContent;

    // Calculate row count / raster info
    let rowCount = 0;
    const isTif = filename.toLowerCase().endsWith('.tif') || filename.toLowerCase().endsWith('.tiff') || fileType === 'geotiff';
    const detectedType = isTif ? 'geotiff' : (fileType || (filename.endsWith('.csv') ? 'csv' : 'geojson'));

    if (detectedType === 'geojson') {
      try {
        const parsedGeo = typeof fileContent === 'string' ? JSON.parse(fileContent) : fileContent;
        if (parsedGeo.features && Array.isArray(parsedGeo.features)) {
          parsedGeo.features = parsedGeo.features.map((f: any) => {
            const props = f.properties || {};
            const mappedProps: any = { ...props };

            // Apply fieldMapping if provided
            if (fieldMapping && typeof fieldMapping === 'object') {
              for (const [targetKey, sourceCol] of Object.entries(fieldMapping)) {
                if (sourceCol && typeof sourceCol === 'string' && props[sourceCol] !== undefined) {
                  mappedProps[targetKey] = props[sourceCol];
                }
              }
            }

            // Merge explicit spatialAttributes if provided
            if (spatialAttributes && typeof spatialAttributes === 'object') {
              Object.assign(mappedProps, spatialAttributes);
            }

            return {
              ...f,
              properties: mappedProps,
            };
          });
          savedContent = JSON.stringify(parsedGeo);
        }
      } catch (err) {
        console.warn('GeoJSON parse warning for spatial attributes injection:', err);
      }
    }

    fs.writeFileSync(filePath, savedContent, 'utf-8');

    if (detectedType === 'csv') {
      rowCount = fileContent.trim().split('\n').length - 1;
      if (rowCount < 0) rowCount = 0;
    } else if (detectedType === 'geojson') {
      try {
        const parsed = JSON.parse(savedContent);
        if (parsed.features && Array.isArray(parsed.features)) {
          rowCount = parsed.features.length;
        }
      } catch {
        rowCount = 1;
      }
    } else if (detectedType === 'geotiff') {
      rowCount = 1; // Raster Grid Layer
    }

    const newLayer = {
      id: `layer_${Date.now()}`,
      name: layerName || filename,
      category: category || 'admin_boundary',
      type: detectedType,
      filename: safeFilename,
      originalFilename: filename,
      url: `/uploads/${safeFilename}`,
      uploadTime: new Date().toISOString(),
      rowCount: detectedType === 'geotiff' ? 'Raster Grid' : rowCount,
      description: description || (detectedType === 'geotiff' ? 'Layer Spatial Raster GeoTIFF (.tif)' : ''),
      content: savedContent,
      spatialAttributes: spatialAttributes || null,
      fieldMapping: fieldMapping || null,
    };

    const index = getLayersIndex();
    index.unshift(newLayer);
    saveLayersIndex(index);

    res.json({
      success: true,
      message: 'File berhasil diunggah dan disimpan dengan atribut spasial.',
      layer: newLayer,
    });
  } catch (err: any) {
    console.error('Upload layer error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Update Layer Spatial Attributes Endpoint
app.post('/api/update-layer-attributes', (req: Request, res: Response) => {
  try {
    const { layerId, spatialAttributes } = req.body;
    if (!layerId || !spatialAttributes) {
      return res.status(400).json({ success: false, error: 'Layer ID dan Atribut Spasial wajib diisi.' });
    }

    const index = getLayersIndex();
    const layerIdx = index.findIndex((l: any) => l.id === layerId);
    if (layerIdx === -1) {
      return res.status(404).json({ success: false, error: 'Layer tidak ditemukan.' });
    }

    const layer = index[layerIdx];
    layer.spatialAttributes = {
      ...(layer.spatialAttributes || {}),
      ...spatialAttributes,
    };

    if (layer.type === 'geojson' && layer.content) {
      try {
        const parsedGeo = JSON.parse(layer.content);
        if (parsedGeo.features && Array.isArray(parsedGeo.features)) {
          parsedGeo.features = parsedGeo.features.map((f: any) => ({
            ...f,
            properties: {
              ...(f.properties || {}),
              ...spatialAttributes,
            },
          }));
          layer.content = JSON.stringify(parsedGeo);
        }
      } catch (err) {
        console.warn('GeoJSON update warning:', err);
      }
    }

    saveLayersIndex(index);
    res.json({ success: true, layer });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get Uploaded Layers List Endpoint
app.get('/api/uploaded-layers', (req: Request, res: Response) => {
  try {
    const layers = getLayersIndex();
    res.json({ success: true, layers });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Delete Uploaded Layer Endpoint
app.post('/api/delete-layer', (req: Request, res: Response) => {
  try {
    const { id } = req.body;
    let index = getLayersIndex();
    const target = index.find((l) => l.id === id);

    if (target) {
      const filePath = path.join(UPLOAD_DIR, target.filename);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
      index = index.filter((l) => l.id !== id);
      saveLayersIndex(index);
    }

    res.json({ success: true, message: 'Layer berhasil dihapus.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Delete All Uploaded Layers Endpoint (Reset Data)
app.post('/api/delete-all-layers', (req: Request, res: Response) => {
  try {
    let index = getLayersIndex();
    for (const target of index) {
      const filePath = path.join(UPLOAD_DIR, target.filename);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }
    saveLayersIndex([]);
    res.json({ success: true, message: 'Semua data pembaruan terunggah berhasil dihapus.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Serve public/uploads statically
app.use('/uploads', express.static(UPLOAD_DIR));

// Serve dist directory
const distPath = path.resolve(process.cwd(), 'dist');
app.use(express.static(distPath));

app.get('*', (req: Request, res: Response) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
